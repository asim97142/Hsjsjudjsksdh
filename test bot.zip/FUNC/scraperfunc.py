import time
import os
from FUNC.defs import *
from datetime import timedelta


async def cc_public_scrape(message, user, bot, channel_link, limit, delete, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        duplicate = 0
        async for msg in user.get_chat_history(channel_link, limit):
            if msg.text:
                content = msg.text
            elif msg.caption:
                content = msg.caption
            else:
                continue

            try:
                for x in content.split("\n"):
                    getcc = await getcards(x)
                    if getcc:
                        if getcc in ccs:
                            duplicate += 1
                        elif amt < limit:
                            ccs.append(getcc)
                            amt += 1
                        else:
                            break

            except:
                getcc = await getcards(content)
                if getcc:
                    if getcc in ccs:
                        duplicate += 1
                    elif amt < limit:
                        ccs.append(getcc)
                        amt += 1
                    else:
                        break
            # try:
            #     for x in content.split("\n"):
            #         getcc = await getcards(x)
            #         if getcc:
            #             if getcc in ccs:
            #                 dublicate += 1
            #             else:
            #                 ccs.append(getcc)
            #                 amt += 1

            # except:
            #     getcc = await getcards(content)
            #     if getcc:
            #         if getcc in ccs:
            #             dublicate += 1
            #         else:
            #             ccs.append(getcc)
            #             amt += 1

        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝙉𝙤 𝘾𝘾 𝙁𝙤𝙪𝙣𝙙 ❌

𝙈𝙚𝙨𝙨𝙖𝙜𝙚: 𝙒𝙚 𝘿𝙞𝙙𝙣'𝙩 𝙁𝙞𝙣𝙙 𝘼𝙣𝙮 𝘾𝘾 𝙄𝙣 @{channel_link}.

</b>"""
            await message.reply_text(resp, message.id)
        else:
            file_name = f"downloads/{amt}x_CC_Scraped_For_{message.from_user.id}_By_@SPYxCHK.txt"
            with open(file_name, "a", encoding="utf-8") as f:
                for x in ccs:
                    cc, mes, ano, cvv = x[0], x[1], x[2], x[3]
                    fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                    f.write(f"{fullcc}\n")

            await bot.delete_messages(message.chat.id, delete.id)
            chat_info = await user.get_chat(channel_link)
            title = chat_info.title
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            hour = int(hours)
            min = int(minutes)
            sec = int(seconds)

            caption = f"""<b>

𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝  ✅

● 𝐒𝐨𝐮𝐫𝐜𝐞: {title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐃𝐮𝐩𝐥𝐢𝐜𝐚𝐭𝐞𝐬 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {duplicate}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX</a>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass


async def check_invite_link(user, channel_link):
    try:
        chat_info = await user.get_chat(channel_link)
        channel_id = chat_info.id
        title = chat_info.title
        return True, channel_id, title
    except:
        try:
            join = await user.join_chat(channel_link)
            title = join.title
            channel_id = join.id
            return True, channel_id, title
        except:
            import traceback
            await error_log(traceback.format_exc())
            return False


async def cc_private_scrape(message, user, bot, channel_id, channel_title, limit, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        dublicate = 0
        resp = f"""<b>
𝐆𝐚𝐭𝐞 : 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐫 

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠 {limit} 𝐂𝐂 𝐅𝐫𝐨𝐦 {channel_title}. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭.

𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠...
</b> """
        delete = await message.reply_text(resp, message.id)
        async for msg in user.get_chat_history(channel_id, limit):
            if msg.text:
                content = msg.text
            elif msg.caption:
                content = msg.caption
            else:
                continue

            try:
                for x in content.split("\n"):
                    getcc = await getcards(x)
                    if getcc:
                        if getcc in ccs:
                            dublicate += 1
                        else:
                            ccs.append(getcc)
                            amt += 1

            except:
                getcc = await getcards(content)
                if getcc:
                    if getcc in ccs:
                        dublicate += 1
                    else:
                        ccs.append(getcc)
                        amt += 1

        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝐍𝐨 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝 ❌

𝙈𝙚𝙨𝙨𝙖𝙜𝙚: 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐂𝐂 𝐰𝐚𝐬 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 {channel_title}.

</b>"""
            await message.reply_text(resp, message.id)

        else:
            file_name = f"downloads/{amt}x_CC_Scraped_For_{message.from_user.id}_By_@SPYxCHK ϟ.txt"
            with open(file_name, "a", encoding="UTF-8") as f:
                for x in ccs:
                    cc, mes, ano, cvv = x[0], x[1], x[2], x[3]
                    fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                    f.write(f"{fullcc}\n")
            await bot.delete_messages(message.chat.id, delete.id)
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            min = int(minutes)
            sec = int(seconds)
            caption = f"""<b>
𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 ✅

● 𝐒𝐨𝐮𝐫𝐜𝐞: {channel_title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐃𝐮𝐩𝐥𝐢𝐜𝐚𝐭𝐞𝐬 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {dublicate}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX </a>
</b>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass


async def bin_public_scrape(message, user, bot, scrape_bin, channel_link, limit, delete, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        dublicate = 0
        async for msg in user.get_chat_history(channel_link, limit):
            msg = str(msg.text)
            try:
                for x in msg.split("\n"):
                    getcc = await getcards(x)
                    if getcc:
                        if getcc in ccs:
                            dublicate += 1
                        else:
                            if scrape_bin in getcc[0][:6]:
                                ccs.append(getcc)
                                amt += 1

            except:
                getcc = await getcards(msg)
                if getcc:
                    if getcc in ccs:
                        dublicate += 1
                    else:
                        ccs.append(getcc)
                        amt += 1
        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝐍𝐨 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝❌

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐂𝐂 𝐰𝐚𝐬 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 @{channel_link} .

</b>"""
            await message.reply_text(resp, message.id)

        else:
            file_name = f"downloads/{amt}x_CC_Scraped_For_{message.from_user.id}_SPYxCHK ϟ.txt"
            with open(file_name, "a", encoding="UTF-8") as f:
                for x in ccs:
                    cc, mes, ano, cvv = x[0], x[1], x[2], x[3]
                    fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                    f.write(f"{fullcc}\n")

            await bot.delete_messages(message.chat.id, delete.id)
            chat_info = await user.get_chat(channel_link)
            title = chat_info.title
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            hour = int(hours)
            min = int(minutes)
            sec = int(seconds)
            caption = f"""<b>
𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 ✅

● 𝐒𝐨𝐮𝐫𝐜𝐞: {title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐁𝐢𝐧: {scrape_bin}
● 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐃𝐮𝐩𝐥𝐢𝐜𝐚𝐭𝐞𝐬 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {dublicate}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX</a>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass


async def bin_private_scrape(message, user, bot, scrape_bin, channel_id, channel_title, limit, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        dublicate = 0
        resp = f"""<b>
𝐆𝐚𝐭𝐞 : 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐫 

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠 {limit} 𝐂𝐂 𝐅𝐫𝐨𝐦 {channel_title} . 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭. 

𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠...
            </b> """
        delete = await message.reply_text(resp, message.id)
        async for msg in user.get_chat_history(channel_id, limit):
            msg = str(msg.text)
            try:
                for x in msg.split("\n"):
                    getcc = await getcards(x)
                    if getcc:
                        if getcc in ccs:
                            dublicate += 1
                        else:
                            if scrape_bin in getcc[0][:6]:
                                ccs.append(getcc)
                                amt += 1

            except:
                getcc = await getcards(msg)
                if getcc:
                    if getcc in ccs:
                        dublicate += 1
                    else:
                        ccs.append(getcc)
                        amt += 1
        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝐍𝐨 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝 ❌

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐂𝐂 𝐰𝐚𝐬 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 {channel_title} .

</b>"""
            await message.reply_text(resp, message.id)

        else:
            file_name = f"downloads/{amt}x_CC_Scraped_For_{message.from_user.id}_SPYxCHK ϟ.txt"
            with open(file_name, "a", encoding="UTF-8") as f:
                for x in ccs:
                    cc, mes, ano, cvv = x[0], x[1], x[2], x[3]
                    fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                    f.write(f"{fullcc}\n")
            await bot.delete_messages(message.chat.id, delete.id)
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            min = int(minutes)
            sec = int(seconds)
            caption = f"""<b>
𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝

● 𝐒𝐨𝐮𝐫𝐜𝐞: {channel_title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐓𝐚𝐫𝐠𝐞𝐭𝐞𝐝 𝐁𝐢𝐧: {scrape_bin}
● 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐃𝐮𝐩𝐥𝐢𝐜𝐚𝐭𝐞𝐬 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {dublicate}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX</a>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass


async def sk_public_scrape(message, user, bot, channel_link, limit, delete, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        dublicate = 0
        async for msg in user.get_chat_history(channel_link, limit):
            msg = str(msg.text)
            if "sk_live" in msg:
                sk = msg.split("sk_live")[1].split(" ")[0]
                if "xxxxx" in sk:
                    pass
                else:
                    if "\n" in sk:
                        sk = sk.split("\n")[0]
                    if "✅" in sk:
                        sk = sk.splice("✅")[1]
                    sk = "sk_live" + sk
                    if sk in ccs:
                        dublicate += 1
                    else:
                        amt += 1
                        ccs.append(sk)

        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝐍𝐨 𝐒𝐤 𝐅𝐨𝐮𝐧𝐝

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐒𝐤 𝐰𝐚𝐬 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 @{channel_link} .

</b>"""
            await message.reply_text(resp, message.id)

        else:
            file_name = f"downloads/{amt}x_SK_Scraped_For_{message.from_user.id}_SPYxCHK ϟ.txt"
            with open(file_name, "a", encoding="UTF-8") as f:
                for x in ccs:
                    f.write(f"{x}\n")

            await bot.delete_messages(message.chat.id, delete.id)
            chat_info = await user.get_chat(channel_link)
            title = chat_info.title
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            hour = int(hours)
            min = int(minutes)
            sec = int(seconds)
            caption = f"""<b>
𝐒𝐤 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 ✅

● 𝐒𝐨𝐮𝐫𝐜𝐞: {title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐒𝐤 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX</a>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass


async def sk_private_scrape(message, user, bot, channel_id, channel_title, limit, role):
    try:
        start = time.perf_counter()
        ccs = []
        amt = 0
        dublicate = 0
        resp = f"""<b>
𝐆𝐚𝐭𝐞 : 𝐒𝐤 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐫 

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠 {limit} 𝐒𝐤 𝐟𝐫𝐨𝐦 {channel_title} . 𝐏𝐥𝐞𝐚𝐬𝐞 𝐰𝐚𝐢𝐭. 

𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐒𝐜𝐫𝐚𝐩𝐩𝐢𝐧𝐠...
            </b> """
        delete = await message.reply_text(resp, message.id)
        async for msg in user.get_chat_history(channel_id, limit):
            msg = str(msg.text)
            if "sk_live" in msg:
                sk = msg.split("sk_live")[1].split(" ")[0]
                if "xxxxx" in sk:
                    pass
                else:
                    if "\n" in sk:
                        sk = sk.split("\n")[0]
                    if "✅" in sk:
                        sk = sk.splice("✅")[1]
                    sk = "sk_live" + sk
                    if sk in ccs:
                        dublicate += 1
                    else:
                        amt += 1
                        ccs.append(sk)

        if amt == 0:
            await bot.delete_messages(message.chat.id, delete.id)
            resp = f"""<b>
𝐍𝐨 𝐒𝐤 𝐅𝐨𝐮𝐧𝐝

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐒𝐤 𝐰𝐚𝐬 𝐅𝐨𝐮𝐧𝐝 𝐢𝐧 {channel_title} .

</b>"""
            await message.reply_text(resp, message.id)

        else:
            file_name = f"downloads/{amt}x_SK_Scraped_For_{message.from_user.id}_SPYxCHK ϟ.txt"
            with open(file_name, "a", encoding="UTF-8") as f:
                for x in ccs:
                    f.write(f"{x}\n")
            await bot.delete_messages(message.chat.id, delete.id)
            taken = str(timedelta(seconds=time.perf_counter() - start))
            hours, minutes, seconds = map(float, taken.split(":"))
            min = int(minutes)
            sec = int(seconds)
            caption = f"""<b>
𝐒𝐤 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 ✅

● 𝐒𝐨𝐮𝐫𝐜𝐞: {channel_title}
● 𝐓𝐚𝐫𝐠𝐞𝐭 𝐀𝐦𝐨𝐮𝐧𝐭: {limit}
● 𝐒𝐤 𝐅𝐨𝐮𝐧𝐝: {amt}
● 𝐃𝐮𝐩𝐥𝐢𝐜𝐚𝐭𝐞𝐬 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: {dublicate}
● 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐝 𝐁𝐲: <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> ♻️ [ {role} ]
● 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: {min} 𝐌𝐢𝐧𝐮𝐭𝐞𝐬 {sec} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
● 𝐁𝐨𝐭 𝐁𝐲 - <a href="tg://user?id=6382444980">企 ROLEX</a>
"""
            await message.reply_document(document=file_name, caption=caption, reply_to_message_id=message.id)
            os.remove(file_name)

    except Exception as e:
        try:
            await bot.delete_messages(message.chat.id, delete.id)
            await message.reply_text(f"<b>𝐄𝐫𝐫𝐨𝐫 ❌\n\n{str(e)}</b>", message.id)
        except:
            pass
