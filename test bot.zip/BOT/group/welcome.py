from pyrogram import Client, filters
import random

MESSAGE = """<b>
👋 Welcome to our group, {name}! ❤️

📜 Group Rules:

🚫 No unwanted links – Let’s keep the chat clean and meaningful.
🚫 No spamming – Quality over quantity; respect everyone’s space.
🚫 No self-promotion – Focus on connecting, not advertising.
🗣️ Be respectful – Treat everyone with kindness and courtesy.

We’re thrilled to have you as part of our family. Let’s create amazing conversations together! 🥰
</b>"""

@Client.on_message(filters.new_chat_members)
async def welcome(client, message):
    try:
        new_members = [u.mention for u in message.new_chat_members]
        names = ", ".join(new_members)
        text = MESSAGE.format(name=names)
        
        # Generate random photo URL
        random_number = random.randint(4, 17)
        photo_url = f"https://t.me/animephotossea/{random_number}"

        # Send the photo with the welcome message
        await message.reply_photo(photo=photo_url, caption=text, quote=True)
    except Exception as e:
        print(f"Error: {e}")
