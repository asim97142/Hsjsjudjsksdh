from pyrogram import Client, filters


@Client.on_message(filters.command("getuser", [".", "/"]))
async def cmd_getuser(client, message):
    try:
        user = message.text.split(" ")[1]
    except IndexError:
        resp = """<b>
𝐔𝐬𝐚𝐠𝐞: 
/𝐠𝐞𝐭𝐮𝐬𝐞𝐫 𝐢𝐝_𝐨𝐫_𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞
        </b>"""
        await message.reply_text(resp, quote=True)
        return

    try:
        get         = await client.get_users(user)
        name        = get.first_name
        id          = get.id
        username    = get.username
        restriction = get.restriction_reason
        scam        = get.scam
        premium     = get.is_premium

        resp = f"""<b>
🔍 𝐈𝐧𝐟𝐨 𝐨𝐟 '{user}' 𝐨𝐧 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦
━━━━━━━━━━━━━━
👤 𝐅𝐢𝐫𝐬𝐭 𝐍𝐚𝐦𝐞: {name}
🆔 𝐈𝐃: {id}
📛 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞: @{username}
🔗 𝐏𝐫𝐨𝐟𝐢𝐥𝐞 𝐋𝐢𝐧𝐤: <a href="tg://user?id={id}">Profile Link</a>
🔒 𝐓𝐆 𝐑𝐞𝐬𝐭𝐫𝐢𝐜𝐭𝐢𝐨𝐧𝐬: {restriction}
🚨 𝐓𝐆 𝐒𝐜𝐚𝐦𝐭𝐚𝐠: {scam}
🌟 𝐓𝐆 𝐏𝐫𝐞𝐦𝐢𝐮𝐦: {premium}
        </b>"""
        await message.reply_text(resp, quote=True)

    except Exception:
        try:
            await message.reply_text("<b>𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐨𝐫 𝐈𝐧𝐜𝐨𝐫𝐫𝐞𝐜𝐭 𝐈𝐃 ❌</b>", quote=True)
        except Exception:
            pass
