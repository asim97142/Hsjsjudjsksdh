import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("pm", [".", "/"]))
async def cmd_pm(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            if message.reply_to_message:
                user_id = str(message.reply_to_message.from_user.id)
            else:
                user_id = str(message.text.split(" ")[1])
        except:
            user_id = message.reply_to_message.from_user.id

        pm_chk = await getuserinfo(user_id)
        status = str(pm_chk["status"])

        if status != "FREE":
            resp = f"""<b>
𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐏𝐫𝐨𝐦𝐨𝐭𝐞𝐝 ⚠️

𝐔𝐬𝐞𝐫 𝐈𝐃 : <a href="tg://user?id={user_id}">{user_id}</a> 
𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐏𝐫𝐞𝐦𝐢𝐮𝐦

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐓𝐡𝐢𝐬 𝐮𝐬𝐞𝐫 𝐢𝐬 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐔𝐬𝐞𝐫. 𝐍𝐨 𝐍𝐞𝐞𝐝 𝐓𝐨 𝐏𝐫𝐨𝐦𝐨𝐭𝐞 𝐀𝐠𝐚𝐢𝐧.
    </b> """
            await message.reply_text(resp, message.id)

        else:
            await premiumuser(user_id)
            resp = f"""<b>
𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐀𝐜𝐭𝐢𝐯𝐚𝐭𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅ 
━━━━━━━━━━━━━━
𝐔𝐬𝐞𝐫 𝐈𝐃 : <a href="tg://user?id={user_id}"> {user_id}</a> 
𝐑𝐨𝐥𝐞 : 𝐏𝐫𝐞𝐦𝐢𝐮𝐦

𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥
    </b> """
            await message.reply_text(resp, message.id)

            user_resp = f"""<b>
𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐏𝐫𝐨𝐦𝐨𝐭𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅ 
━━━━━━━━━━━━━━ 
𝐔𝐬𝐞𝐫 𝐈𝐃 : {user_id} 
𝐑𝐨𝐥𝐞 : 𝐏𝐫𝐞𝐦𝐢𝐮𝐦

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐬 ! 𝐘𝐨𝐮𝐫 𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐏𝐫𝐨𝐦𝐨𝐭𝐞𝐝 𝐓𝐨 "𝐏𝐫𝐞𝐦𝐢𝐮𝐦" 𝐔𝐬𝐞𝐫. 𝐄𝐧𝐣𝐨𝐲!
    </b> """
            await Client.send_message(user_id, user_resp)

    except:
        import traceback
        await error_log(traceback.format_exc())
