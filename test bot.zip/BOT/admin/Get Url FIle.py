import json
import os
from pyrogram import Client, filters
from datetime import datetime

@Client.on_message(filters.command("furl", prefixes=[".", "/"]))
async def send_file_to_owner(client, message):
    try:
        # Extract the user ID and OWNER_ID from config file
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]

        # Check if the user is the owner
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬❤️ !</b>"""
            await message.reply_text(resp, message.id)
            return

        # Get the date (DD-MM-YY) from the command
        user_input = message.text.split(maxsplit=1)
        
        if len(user_input) < 2:
            await message.reply_text("𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐚 𝐝𝐚𝐭𝐞 𝐢𝐧 𝐭𝐡𝐞 𝐟𝐨𝐫𝐦𝐚𝐭 𝐃𝐃-𝐌𝐌-𝐘𝐘.", quote=True)
            return
        
        date_str = user_input[1].strip()
        
        # Validate the date format (DD-MM-YY)
        try:
            file_date = datetime.strptime(date_str, "%d-%m-%y").strftime("%d-%m-%y")
        except ValueError:
            await message.reply_text("𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐝𝐚𝐭𝐞 𝐟𝐨𝐫𝐦𝐚𝐭! 𝐏𝐥𝐞𝐚𝐬𝐞 𝐮𝐬𝐞 𝐃𝐃-𝐌𝐌-𝐘𝐘.", quote=True)
            return
        
        # Define the file path
        folder_path = 'URL'
        filename = f"{folder_path}/Url_{file_date}.txt"

        # Check if the file exists
        if not os.path.exists(filename):
            await message.reply_text(f"𝐅𝐢𝐥𝐞 𝐟𝐨𝐫 𝐭𝐡𝐞 𝐝𝐚𝐭𝐞 {file_date} 𝐧𝐨𝐭 𝐟𝐨𝐮𝐧𝐝.", quote=True)
            return
        
        # Send the file to the owner
        await client.send_document(chat_id=user_id, document=filename)
        await message.reply_text(f"𝐇𝐞𝐫𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐟𝐢𝐥𝐞 𝐟𝐨𝐫 {file_date}.", quote=True)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_message(filters.command("surl", prefixes=[".", "/"]))
async def send_file_to_owner(client, message):
    try:
        # Extract the user ID and OWNER_ID from config file
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]

        # Check if the user is the owner
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬❤️ !</b>"""
            await message.reply_text(resp, message.id)
            return

        # Get the date (DD-MM-YY) from the command
        user_input = message.text.split(maxsplit=1)
        
        if len(user_input) < 2:
            await message.reply_text("𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐚 𝐝𝐚𝐭𝐞 𝐢𝐧 𝐭𝐡𝐞 𝐟𝐨𝐫𝐦𝐚𝐭 𝐃𝐃-𝐌𝐌-𝐘𝐘.", quote=True)
            return
        
        date_str = user_input[1].strip()
        
        # Validate the date format (DD-MM-YY)
        try:
            file_date = datetime.strptime(date_str, "%d-%m-%y").strftime("%d-%m-%y")
        except ValueError:
            await message.reply_text("𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐝𝐚𝐭𝐞 𝐟𝐨𝐫𝐦𝐚𝐭! 𝐏𝐥𝐞𝐚𝐬𝐞 𝐮𝐬𝐞 𝐃𝐃-𝐌𝐌-𝐘𝐘.", quote=True)
            return
        
        # Define the file path
        folder_path = 'URL'
        filename = f"{folder_path}/SUrl_{file_date}.txt"

        # Check if the file exists
        if not os.path.exists(filename):
            await message.reply_text(f"𝐅𝐢𝐥𝐞 𝐟𝐨𝐫 𝐭𝐡𝐞 𝐝𝐚𝐭𝐞 {file_date} 𝐧𝐨𝐭 𝐟𝐨𝐮𝐧𝐝.", quote=True)
            return
        
        # Send the file to the owner
        await client.send_document(chat_id=user_id, document=filename)
        await message.reply_text(f"𝐇𝐞𝐫𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐟𝐢𝐥𝐞 𝐟𝐨𝐫 {file_date}.", quote=True)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
