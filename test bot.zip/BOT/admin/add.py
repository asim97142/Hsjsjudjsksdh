import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *

@Client.on_message(filters.command("add", [".", "/"]))
async def cmd_add(client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = (
                "<b>𝐀𝐜𝐜𝐞𝐬𝐬 𝐃𝐞𝐧𝐢𝐞𝐝 ❌</b>\n\n"
                "<i>𝐘𝐨𝐮 𝐝𝐨 𝐧𝐨𝐭 𝐡𝐚𝐯𝐞 𝐩𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧 𝐭𝐨 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬 𝐜𝐨𝐦𝐦𝐚𝐧𝐝.</i>\n"
            )
            await message.reply_text(resp, quote=True)
            return

        try:
            chat_id = str(message.text.split(" ")[1])
        except IndexError:
            chat_id = str(message.chat.id)

        getchat = await getchatinfo(chat_id)
        getchat = str(getchat)
        
        if getchat == "None":
            await addchat(chat_id)
            resp = (
                "<b>𝐆𝐫𝐨𝐮𝐩 𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ✅</b>\n\n"
                f"<b>𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃:</b> <code>{chat_id}</code>\n\n"
                "<i>𝐓𝐡𝐢𝐬 𝐠𝐫𝐨𝐮𝐩 𝐢𝐬 𝐧𝐨𝐰 𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭.</i>"
            )
            await message.reply_text(resp, quote=True)
            
            chat_resp = (
                "<b>𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ✅</b>\n\n"
                f"<b>𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃::</b> <code>{chat_id}</code>\n\n"
                "<i>𝐓𝐡𝐢𝐬 𝐠𝐫𝐨𝐮𝐩 𝐢𝐬 𝐧𝐨𝐰 𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐨𝐮𝐫 𝐛𝐨𝐭. 𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐛𝐲 @𝐒𝐏𝐘𝐱𝐒𝐏𝐘𝐃𝐄.</i>"
            )
            try:
                await client.send_message(chat_id, chat_resp)
            except Exception:
                pass

        else:
            find = await getchatinfo(chat_id)
            find = str(find)
            if find != "None":
                resp = (
                    "<b>𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ⚠️</b>\n\n"
                    f"<b>𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃:</b> <code>{chat_id}</code>\n\n"
                    "<i>𝐓𝐡𝐢𝐬 𝐠𝐫𝐨𝐮𝐩 𝐢𝐬 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭.</i>"
                )
                await message.reply_text(resp, quote=True)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
