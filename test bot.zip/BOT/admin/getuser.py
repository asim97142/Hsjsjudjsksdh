import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("get", [".", "/"]))
async def cmd_add(Client, message):
    try:
        # Get the user ID of the sender
        user_id = str(message.from_user.id)

        # Load the OWNER_ID from the configuration file
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]

        # Check if the user has permission to use the command
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        # Ensure a user ID is provided after the command
        command_parts = message.text.split(" ")
        if len(command_parts) < 2:
            resp = """<b>
𝐔𝐬𝐚𝐠𝐞 𝐄𝐫𝐫𝐨𝐫 ⚠️

𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐚 𝐯𝐚𝐥𝐢𝐝 𝐮𝐬𝐞𝐫 𝐈𝐃 𝐚𝐟𝐭𝐞𝐫 𝐭𝐡𝐞 𝐜𝐨𝐦𝐦𝐚𝐧𝐝. 
𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : <code>/𝐠𝐞𝐭 123456789</code>
</b>"""
            await message.reply_text(resp, message.id)
            return

        # Fetch user information using the provided user ID
        target_user_id = command_parts[1]
        info = await getuserinfo(target_user_id)

        # Extract information from the response
        status = info["status"]
        plan = info["plan"]
        expiry = info["expiry"]
        credit = info["credit"]
        totalkey = info["totalkey"]
        reg_at = info["reg_at"]

        # Prepare the response
        send_info = f"""<b>
<b>{target_user_id}</b> 𝐈𝐧𝐟𝐨 ⚡
━━━━━━━━━━━━━━
● 𝐈𝐃 : <code>{target_user_id}</code>
● 𝐏𝐫𝐨𝐟𝐢𝐥𝐞 𝐋𝐢𝐧𝐤 : <a href="tg://user?id={target_user_id}">𝐏𝐫𝐨𝐟𝐢𝐥𝐞 𝐋𝐢𝐧𝐤</a>
● 𝐒𝐭𝐚𝐭𝐮𝐬 : {status}
● 𝐂𝐫𝐞𝐝𝐢𝐭 : {credit}
● 𝐏𝐥𝐚𝐧 : {plan}
● 𝐏𝐥𝐚𝐧 𝐄𝐱𝐩𝐢𝐫𝐲 : {expiry}
● 𝐊𝐞𝐲 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 : {totalkey}
● 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐚𝐭 : {reg_at}</b>
"""
        await message.reply_text(send_info, message.id)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
