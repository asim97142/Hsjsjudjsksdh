import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("ac", [".", "/"]))
async def cmd_ac(Client, message):
    try:
        # Get the user ID of the sender
        user_id = str(message.from_user.id)

        # Load the OWNER_ID from the configuration file
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]

        # Check if the user has permission to use the command
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        # Ensure there are enough arguments
        command_parts = message.text.split(" ")
        if len(command_parts) < 3:
            resp = """<b>
𝐔𝐬𝐚𝐠𝐞 𝐄𝐫𝐫𝐨𝐫 ⚠️

𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐭𝐡𝐞 𝐫𝐞𝐪𝐮𝐢𝐫𝐞𝐝 𝐚𝐫𝐠𝐮𝐦𝐞𝐧𝐭𝐬 : 𝐚𝐦𝐨𝐮𝐧𝐭 𝐚𝐧𝐝 𝐮𝐬𝐞𝐫 𝐈𝐃.
𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : <code>/𝐚𝐜 100 123456789<code>
</b>"""
            await message.reply_text(resp, message.id)
            return

        # Parse the arguments
        amt = int(command_parts[1])
        target_user_id = command_parts[2]

        # Fetch user info and update credits
        get_info = await getuserinfo(target_user_id)
        previous_credit = int(get_info["credit"])
        value = previous_credit + amt if previous_credit >= 0 else amt

        # Update the credit
        await directcredit(target_user_id, value)

        # Send success response
        resp = f"""<b>
𝐂𝐫𝐞𝐝𝐢𝐭 𝐀𝐝𝐝𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
𝐀𝐦𝐨𝐮𝐧𝐭 : {amt}
𝐔𝐬𝐞𝐫 𝐈𝐃 : <a href="tg://user?id={target_user_id}">{target_user_id}</a>
𝐏𝐫𝐞𝐯𝐢𝐨𝐮𝐬 𝐂𝐫𝐞𝐝𝐢𝐭 : {previous_credit}
𝐀𝐟𝐭𝐞𝐫 𝐂𝐫𝐞𝐝𝐢𝐭 : {value}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐂𝐫𝐞𝐝𝐢𝐭 𝐀𝐝𝐝𝐞𝐝 𝐭𝐨 𝐭𝐡𝐢𝐬 𝐔𝐬𝐞𝐫 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲.
</b>"""
        await message.reply_text(resp, message.id)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
