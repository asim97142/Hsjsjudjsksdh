import httpx
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *
import re
import os


@Client.on_message(filters.command("fl", [".", "/"]))
async def filter(Client, message):
    try:
        checkall = await check_all_thing(Client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        input_text = None
        if message.reply_to_message:
            input_text = message.reply_to_message.text
        else:
            input_text = message.text[len('/fl'):]

        if message.reply_to_message and message.reply_to_message.document:
            file = await message.reply_to_message.download()
            with open(file, 'r') as f:
                input_text = f.read()
            os.remove(file)

        if input_text:
            all_cards = input_text.split('\n')
        else:
            all_cards = []

        cards = ""
        for cc in all_cards:
            try:
                x = re.findall(r'\d+', cc)
                ccn = x[0]
                mm = x[1]
                yy = x[2]
                cvv = x[3]
                if mm.startswith('2'):
                    mm, yy = yy, mm
                if len(mm) >= 3:
                    mm, yy, cvv = yy, cvv, mm
                if len(ccn) < 15 or len(ccn) > 16:
                    pass
                else:
                    cards += f"{ccn}|{mm}|{yy}|{cvv}\n"
            except:
                pass

        if cards:
            if len(cards.split('\n')) >= 32:
                with open('𝐒𝐧𝐨✘s-𝐅𝐢𝐥𝐭𝐞𝐫𝐞𝐝.txt', 'w') as file:
                    file.write(cards)
                await message.reply_document('𝐒𝐧𝐨✘s-𝐅𝐢𝐥𝐭𝐞𝐫𝐞𝐝.txt', quote=True)
                os.remove('𝐒𝐧𝐨✘s-𝐅𝐢𝐥𝐭𝐞𝐫𝐞𝐝.txt')
            else:
                await message.reply_text(f"""<code>{cards}</code>""", quote=True)
        else:
            resp = """<b>
𝐅𝐢𝐥𝐭𝐞𝐫 𝐅𝐚𝐢𝐥𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐍𝐨 𝐕𝐚𝐥𝐢𝐝 𝐂𝐂 𝐅𝐨𝐮𝐧𝐝 𝐢𝐧 𝐭𝐡𝐞 𝐈𝐧𝐩𝐮𝐭.
            </b>"""
            await message.reply_text(resp, quote=True)

    except Exception as e:
        print("Error:", str(e))
