import os
import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *

@Client.on_message(filters.command("restart", [".", "/"]))
async def cmd_reboot(client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        await message.reply_text("𝐂𝐥𝐞𝐚𝐫𝐢𝐧𝐠 𝐜𝐚𝐜𝐡𝐞 𝐟𝐢𝐥𝐞𝐬 𝐚𝐧𝐝 𝐫𝐞𝐛𝐨𝐨𝐭𝐢𝐧𝐠 𝐭𝐡𝐞 𝐬𝐲𝐬𝐭𝐞𝐦...")
        
        os.system("python3 /root/new/cache_clear.py")
        
        os.system("sudo reboot")

    except Exception as e:
        await message.reply_text(f"𝐀𝐧 𝐞𝐫𝐫𝐨𝐫 𝐨𝐜𝐜𝐮𝐫𝐫𝐞𝐝: {str(e)}")
        import traceback
        await error_log(traceback.format_exc())
