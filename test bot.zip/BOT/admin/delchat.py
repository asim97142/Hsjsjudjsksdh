import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("del", [".", "/"]))
async def cmd_del(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(
            open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp)
            return
        else:
            try:
                chat_id = str(message.text.split(" ")[1])
            except:
                chat_id = str(message.chat.id)

            getchat = await getchatinfo(chat_id)
            getchat = str(getchat)

            if getchat != "None":
                await delchat(chat_id)
                resp = f"""<b>
𝐆𝐫𝐨𝐮𝐩 𝐃𝐞𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ❌

𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃 : {chat_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐓𝐡𝐢𝐬 𝐆𝐫𝐨𝐮𝐩 (<code>{chat_id}</code>) 𝐢𝐬 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐃𝐞𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝.
       </b> """
                await message.reply_text(resp)
                user_resp = f"""<b>
𝐃𝐞𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ❌

𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃: {chat_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐓𝐡𝐢𝐬 𝐠𝐫𝐨𝐮𝐩 𝐢𝐬 𝐧𝐨 𝐥𝐨𝐧𝐠𝐞𝐫 𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭.
       </b> """
                try:
                    await Client.send_message(chat_id, user_resp)
                except:
                    pass
            else:
                resp = f"""<b>
𝐂𝐡𝐚𝐭 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝⚠️

𝐆𝐫𝐨𝐮𝐩 𝐂𝐡𝐚𝐭 𝐈𝐃 : {chat_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐓𝐡𝐢𝐬 𝐆𝐫𝐨𝐮𝐩 (<code>{chat_id}</code>) 𝐢𝐬 𝐧𝐨𝐭 𝐢𝐧 𝐭𝐡𝐞 𝐥𝐢𝐬𝐭 𝐨𝐟 𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐜𝐡𝐚𝐭𝐬.
       </b> """
                await message.reply_text(resp)

    except Exception as e:
        await message.reply_text(str(e))
        await error_log(traceback.format_exc())
