import json
from .func import *
from pyrogram import Client, filters

# Define a modern UI message for no permission
NO_PERMISSION_MESSAGE = """<b>
╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️ 🧡!
</b>"""

# Define a success message header
REDEEM_GENERATED_HEADER = """<b>𝐑𝐞𝐝𝐞𝐞𝐦 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐞𝐝 ✅</b>\n"""

# Define a command to generate redeem codes
@Client.on_message(filters.command("gc", [".", "/"]))
async def generate_redeem_codes(client, message):
    try:
        user_id = str(message.from_user.id)
        with open("FILES/config.json", "r", encoding="utf-8") as config_file:
            config = json.load(config_file)
        
        owner_ids = config.get("OWNER_ID", [])

        if user_id not in owner_ids:
            await message.reply_text(NO_PERMISSION_MESSAGE, message.id)
            return

        try:
            amount = int(message.text.split(" ")[1])
        except (IndexError, ValueError):
            amount = 10

        response_text = REDEEM_GENERATED_HEADER

        for _ in range(amount):
            redeem_code = f"SPYs-{gcgenfunc()}{gcgenfunc()}{gcgenfunc()}-PRO"
            await insert_pm(redeem_code)
            response_text += f"➔ <code>{redeem_code}</code>\n"

        response_text += """<b>\n𝐘𝐨𝐮 𝐜𝐚𝐧 𝐫𝐞𝐝𝐞𝐞𝐦 𝐭𝐡𝐢𝐬 𝐜𝐨𝐝𝐞 𝐮𝐬𝐢𝐧𝐠 𝐭𝐡𝐢𝐬 𝐜𝐨𝐦𝐦𝐚𝐧𝐝: /𝐫𝐞𝐝𝐞𝐞𝐦 𝐒𝐏𝐘𝐬-𝐗𝐗𝐗𝐗-𝐏𝐑𝐎</b>"""
        
        await message.reply_text(response_text, message.id)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())

