from .func import *
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("redeem", [".", "/"]))
async def cmd_gc(Client, message):
    try:
        user_id = str(message.from_user.id)
        regdata = await getuserinfo(user_id)
        regdata = str(regdata)

        if regdata == "None":
            resp = f"""<b>
𝐔𝐧𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐔𝐬𝐞𝐫𝐬 

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐂𝐚𝐧'𝐭 𝐔𝐬𝐞 𝐌𝐞 𝐔𝐧𝐥𝐞𝐬𝐬 𝐘𝐨𝐮 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐅𝐢𝐫𝐬𝐭.

𝐓𝐲𝐩𝐞 /register 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            gc  = message.text.split(" ")[1]
        except:
            resp = "<b>𝐏𝐥𝐞𝐚𝐬𝐞 𝐏𝐫𝐨𝐯𝐢𝐝𝐞 𝐀 𝐕𝐚𝐥𝐢𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 ❌</b>"
            await message.reply_text(resp, message.id)
            return

        detail = await getgc(gc)
        if str(detail) == "None":
            resp = "<b>𝐏𝐥𝐞𝐚𝐬𝐞 𝐏𝐫𝐨𝐯𝐢𝐝𝐞 𝐀 𝐕𝐚𝐥𝐢𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 ❌</b>"
            await message.reply_text(resp, message.id)
            return
        

        get_user_info = usersdb.find_one({"id": user_id})
        if "∞" in get_user_info["plan"]:
            resp = "<b>𝐘𝐨𝐮 𝐡𝐚𝐯𝐞 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐚𝐜𝐭𝐢𝐯𝐞 𝐩𝐥𝐚𝐧, 𝐲𝐨𝐮 𝐜𝐚𝐧𝐧𝐨𝐭 𝐫𝐞𝐝𝐞𝐞𝐦!</b>"
            await message.reply_text(resp, message.id)
            return


        status = str(detail["status"])
        type   = str(detail["type"])
        if status == "ACTIVE" and type == "PREMIUM":
            await onlycredits(user_id)
            await updategc(gc)
            resp = f"""<b>
𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
● 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 : {gc}
● 𝐔𝐬𝐞𝐫 𝐈𝐃 : {user_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐳 ! 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐭𝐨 𝐘𝐨𝐮𝐫 𝐀𝐜𝐨𝐨𝐮𝐧𝐭 𝐀𝐧𝐝 𝐘𝐨𝐮 𝐆𝐨𝐭 "100 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 + 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐒𝐮𝐛𝐬𝐜𝐫𝐢𝐩𝐭𝐢𝐨𝐧 ".
</b>"""
            await message.reply_text(resp, message.id)

        elif status == "ACTIVE" and type == "PLAN1":
            await plan1gc(user_id)
            await updategc(gc)
            resp = f"""<b>
𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
● 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞: {gc}
● 𝐔𝐬𝐞𝐫 𝐈𝐃: {user_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐳 ! 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐭𝐨 𝐘𝐨𝐮𝐫 𝐀𝐜𝐨𝐨𝐮𝐧𝐭 𝐀𝐧𝐝 𝐘𝐨𝐮 𝐆𝐨𝐭 "𝐒𝐭𝐚𝐫𝐭𝐞𝐫 𝐏𝐥𝐚𝐧 𝐅𝐨𝐫 1 𝐃𝐚𝐲𝐬 " .
</b>"""
            await message.reply_text(resp, message.id)

        elif status == "ACTIVE" and type == "PLAN2":
            await plan2gc(user_id)
            await updategc(gc)
            resp = f"""<b>
𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
● 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 : {gc}
● 𝐔𝐬𝐞𝐫 𝐈𝐃 : {user_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐬 ! 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐢𝐬 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐭𝐨 𝐘𝐨𝐮𝐫 𝐀𝐜𝐨𝐨𝐮𝐧𝐭 𝐀𝐧𝐝 "𝐒𝐢𝐥𝐯𝐞𝐫 𝐏𝐥𝐚𝐧 𝐅𝐨𝐫 15 𝐃𝐚𝐲𝐬"𝐢𝐬 𝐀𝐜𝐭𝐢𝐯𝐚𝐭𝐞𝐝 .
</b>"""
            await message.reply_text(resp, message.id)

        elif status == "ACTIVE" and type == "PLAN3":
            await plan3gc(user_id)
            await updategc(gc)
            resp = f"""<b>
𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
● 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞: {gc}
● 𝐔𝐬𝐞𝐫 𝐈𝐃: {user_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐂𝐨𝐧𝐠𝐫𝐚𝐭𝐬 ! 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐢𝐬 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐭𝐨 𝐘𝐨𝐮𝐫 𝐀𝐜𝐨𝐨𝐮𝐧𝐭 𝐀𝐧𝐝 "𝐆𝐨𝐥𝐝 𝐏𝐥𝐚𝐧 𝐅𝐨𝐫 30 𝐃𝐚𝐲𝐬 "𝐢𝐬 𝐀𝐜𝐭𝐢𝐯𝐚𝐭𝐞𝐝  .
</b>"""
            await message.reply_text(resp, message.id)

        elif status == "USED":
            resp = f"""<b>
𝐈𝐭𝐬 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐫𝐞𝐞𝐝𝐞𝐦𝐞𝐝 ⚠️

𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 :  {gc}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐆𝐈𝐟𝐭𝐜𝐨𝐝𝐞 𝐢𝐬 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐫𝐞𝐝𝐞𝐞𝐦𝐞𝐝 𝐛𝐲 𝐚𝐧𝐨𝐭𝐡𝐞𝐫 𝐟𝐨𝐫𝐭𝐮𝐧𝐚𝐭𝐞 𝐮𝐬𝐞𝐫.
</b> """
            await message.reply_text(resp, message.id)

        else:
            resp = f"""<b>
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 ❌

𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 :  {gc}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐢𝐬 𝐈𝐧𝐯𝐚𝐥𝐢𝐝!  
        </b>"""
            await message.reply_text(resp, message.id)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())
