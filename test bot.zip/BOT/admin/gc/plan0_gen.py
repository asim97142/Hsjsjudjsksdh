import json
from .func import *
from pyrogram import Client, filters
from FUNC.defs import error_log


@Client.on_message(filters.command("getplan0", [".", "/"]))
async def cmd_getplan0(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>
╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!

</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            amt = int(message.text.split(" ")[1])
        except:
            amt = 1

        text = f"""<b>𝐆𝐢𝐟𝐭𝐜𝐨𝐝𝐞 𝐆𝐞𝐧𝐚𝐫𝐚𝐭𝐞𝐝 ✅
𝐀𝐦𝐨𝐮𝐧𝐭 : {amt}\n</b>"""

        for _ in range(amt):
            GC = f"OWNER-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
            await insert_plan0(GC)
            text += f"""
➔ <code>{GC}</code>
<b>𝐕𝐚𝐥𝐮𝐞 : 0𝐰𝐧𝐞𝐫 𝐏𝐥𝐚𝐧 ∞ 𝐃𝐚𝐲𝐬</b>\n"""

        text += f"""
<b>𝐅𝐨𝐫 𝐑𝐞𝐝𝐞𝐞𝐦𝐭𝐢𝐨𝐧 
𝐓𝐲𝐩𝐞 /𝐫𝐞𝐝𝐞𝐞𝐦 OWNER-XXXX-XXXX-XXXX</b>"""

        await message.reply_text(text, message.id)

    except:
        import traceback
        await error_log(traceback.format_exc())
