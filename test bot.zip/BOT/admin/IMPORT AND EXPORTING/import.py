import traceback
from pyrogram import Client, filters
from FUNC.usersdb_func import *
import asyncio
import pymongo
import json
from mongodb import client, folder
from pathlib import Path
import time

users_db = folder.USERSDB
chats_auth_db = folder.CHATS_AUTH
gc_db = folder.GCDB


@Client.on_message(filters.command("import", [".", "/"]))
async def stats(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>𝐘𝐨𝐮 𝐃𝐨𝐧'𝐭 𝐇𝐚𝐯𝐞 𝐏𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧 𝐓𝐨 𝐔𝐬𝐞 𝐓𝐡𝐢𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝.    
𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐁𝐨𝐭 𝐎𝐰𝐧𝐞𝐫 @𝐒𝐏𝐘𝐱𝐒𝐏𝐘𝐃𝐄 !</b>"""
            msg1 = await message.reply_text(resp, message.id)
        else:
            try:
                file_name = "import.json"
                await message.reply_to_message.download(file_name=file_name)
                all_data = (
                    open("downloads/import.json", "r", encoding="UTF-8")
                    .read()
                    .splitlines()
                )
                data_list = []
                amt = 0
                for i in all_data:
                    amt += 1
                    data = json.loads(i)
                    data_list.append(data)
                getfile = True
            except Exception as e:
                getfile = False
            if getfile == True:
                try:
                    msg = message.text.split(" ")[1]
                    status = True
                except:
                    status = False
                    resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐅𝐨𝐫𝐦𝐚𝐭 ❌

 𝑼𝒔𝒂𝒈𝒆: 
 𝑭𝒐𝒓 𝑼𝒔𝒆𝒓𝒔 𝑫𝒂𝒕𝒂 𝑰𝒎𝒑𝒐𝒓𝒕 : /𝒊𝒎𝒑𝒐𝒓𝒕 𝒖𝒔𝒆𝒓𝒔 
 𝑭𝒐𝒓 𝑪𝒉𝒂𝒕𝒔 𝑫𝒂𝒕𝒂 𝑰𝒎𝒑𝒐𝒓𝒕 : /𝒊𝒎𝒑𝒐𝒓𝒕 𝒄𝒉𝒂𝒕𝒔 
 𝑭𝒐𝒓 𝑮𝑪 𝑫𝒂𝒕𝒂 𝑰𝒎𝒑𝒐𝒓𝒕 : /𝒊𝒎𝒑𝒐𝒓𝒕 𝒈𝒄
                   </b> """
                    await message.reply_text(resp, message.id)
                if "users" in msg and status == True:
                    try:
                        resp = "<b>𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 𝐭𝐨 𝐗𝐂𝐂 𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞...</b>"
                        delete = await message.reply_text(resp, message.id)
                        start = time.time()
                        insert = users_db.insert_many(data_list)
                        end = time.time()
                        await Client.delete_messages(message.chat.id, delete.id)
                        resp = f"""<b>
𝐈𝐌𝐏𝐎𝐑𝐓 𝐃𝐎𝐍𝐄 ✅

𝐓𝐨𝐭𝐚𝐥 𝐍𝐮𝐦𝐛𝐞𝐫 : {amt}
𝐃𝐚𝐭𝐚 𝐓𝐲𝐩𝐞 : 𝐉𝐒𝐎𝐍
𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧 : {end - start:0.4f}s
𝐑𝐞𝐪𝐮𝐞𝐬𝐭𝐞𝐝 𝐓𝐢𝐦𝐞 : {message.date}
                        </b>"""
                        await message.reply_text(resp, message.id)
                        if insert:
                            name = "downloads/import.json"
                            my_file = Path(name)
                            my_file.unlink()
                    except:
                        await message.reply_text("𝐄𝐫𝐫𝐨𝐫 𝐨𝐜𝐜𝐮𝐫𝐫𝐞𝐝 𝐰𝐡𝐢𝐥𝐞 𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 ❌", message.id)
                elif "chats" in msg and status == True:
                    try:
                        resp = "<b>𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 𝐭𝐨 𝐗𝐂𝐂 𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞...</b>"
                        delete = await message.reply_text(resp, message.id)
                        start = time.time()
                        insert = chats_auth_db.insert_many(data_list)
                        end = time.time()
                        await Client.delete_messages(message.chat.id, delete.id)
                        resp = f"""<b>
𝐈𝐌𝐏𝐎𝐑𝐓 𝐃𝐎𝐍𝐄 ✅

𝐓𝐨𝐭𝐚𝐥 𝐍𝐮𝐦𝐛𝐞𝐫 : {amt}
𝐃𝐚𝐭𝐚 𝐓𝐲𝐩𝐞 : 𝐉𝐒𝐎𝐍
𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧 : {end - start:0.4f}s
𝐑𝐞𝐪𝐮𝐞𝐬𝐭𝐞𝐝 𝐓𝐢𝐦𝐞 : {message.date}
                        </b>"""
                        await message.reply_text(resp, message.id)
                        if insert:
                            name = "downloads/import.json"
                            my_file = Path(name)
                            my_file.unlink()
                    except:
                        await message.reply_text("𝐄𝐫𝐫𝐨𝐫 𝐨𝐜𝐜𝐮𝐫𝐫𝐞𝐝 𝐰𝐡𝐢𝐥𝐞 𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 ❌", message.id)
                elif "gc" in msg and status == True:
                    try:
                        resp = "<b>𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 𝐭𝐨 𝐗𝐂𝐂 𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞...</b>"
                        delete = await message.reply_text(resp, message.id)
                        start = time.time()
                        insert = gc_db.insert_many(data_list)
                        end = time.time()
                        await Client.delete_messages(message.chat.id, delete.id)
                        resp = f"""<b>
𝐈𝐌𝐏𝐎𝐑𝐓 𝐃𝐎𝐍𝐄 ✅

𝐓𝐨𝐭𝐚𝐥 𝐍𝐮𝐦𝐛𝐞𝐫: {amt}
𝐃𝐚𝐭𝐚 𝐓𝐲𝐩𝐞 : 𝐉𝐒𝐎𝐍
𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧 : {end - start:0.4f}s
𝐑𝐞𝐪𝐮𝐞𝐬𝐭𝐞𝐝 𝐓𝐢𝐦𝐞 : {message.date}
                        </b>"""
                        await message.reply_text(resp, message.id)
                        if insert:
                            name = "downloads/import.json"
                            my_file = Path(name)
                            my_file.unlink()
                    except:
                        await message.reply_text(
                            "<b>𝐄𝐫𝐫𝐨𝐫 𝐨𝐜𝐜𝐮𝐫𝐫𝐞𝐝 𝐰𝐡𝐢𝐥𝐞 𝐈𝐦𝐩𝐨𝐫𝐭𝐢𝐧𝐠 ❌</b>", message.id
                        )
                else:
                    await message.reply_text(
                        "<b>𝐏𝐥𝐞𝐚𝐬𝐞 𝐬𝐩𝐞𝐜𝐢𝐟𝐲 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞 𝐧𝐚𝐦𝐞 ❌</b>", message.id
                    )
            else:
                await message.reply_text(
                    "<b>𝐏𝐫𝐨𝐯𝐝𝐞 𝐉𝐬𝐨𝐧 𝐟𝐢𝐥𝐞 𝐟𝐨𝐫 𝐢𝐦𝐩𝐨𝐫𝐭 ❌</b>", message.id
                )
    except Exception as e:
        await message.reply_text(e, message.id)
