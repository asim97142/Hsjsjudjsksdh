import asyncio
from datetime import datetime, timedelta
from pyrogram import Client, filters
import pymongo
import json
from FUNC.defs import *
from FUNC.usersdb_func import *

# MongoDB setup
client = pymongo.MongoClient("mongodb://localhost:27017")  # Make sure MongoDB is running
db = client["MASTER_DATABASE"]  # Use your specific database name
users_collection = db["USERS"]  # Collection name for users (change to your actual collection name)

async def get_all_users_and_chats():
    users = await getallusers()  # Assuming this fetches all users
    chats = await getallchat()   # Assuming this fetches all chat groups
    all_user_ids = [int(user["id"]) for user in users]  # User IDs from the database
    all_chat_ids = [chat["id"] for chat in chats]  # Chat IDs from the database
    return all_user_ids + all_chat_ids


# Function to handle expiry parsing (only date, no time)
def parse_expiry(expiry_str):
    """
    Parses the expiry date string into a date object (ignores time).
    """
    print(f"Parsing expiry date: {expiry_str}")  # Debugging: parsing expiry date
    try:
        if expiry_str == "N/A":  # Skip users with "N/A" as expiry
            print("Expiry is 'N/A', skipping user.")  # Debugging: N/A expiry
            return None
        # We are assuming the expiry is in the format 'DD-MM-YYYY'
        return datetime.strptime(expiry_str, "%d-%m-%Y").date()
    except Exception as e:
        print(f"Error parsing expiry date: {expiry_str}. Error: {str(e)}")
        return None



# New command to remind users about their plan expiry
@Client.on_message(filters.command("remind", [".", "/"]))
async def cmd_remind(client, message):
    try:
        print(f"Received reminder command from user: {message.from_user.id}")  # Debugging: received message
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]

        # Check if the user is authorized (assuming only the owner can execute the remind command)
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp)
            print(f"User {user_id} is not authorized.")  # Debugging: not authorized
            return

        # Get current time (only the date part)
        now = datetime.now().date()
        print(f"Current Date: {now}")  # Debugging: current date

        # Fetch all registered users
        get_user = await getallusers()

        # List to store users who need the reminder
        reminder_users = []

        # Check each user's expiry date
        for user in get_user:
            user_id = str(user.get("id"))  # Using .get() to avoid key errors
            print(f"Checking expiry for user {user_id}...")  # Debugging: checking user

            results = await getuserinfo(user_id)

            if results is None:
                print(f"No data found for user {user_id}. Skipping...")  # Debugging: no data
                continue  # Skip if no data is found

            # Get expiry date from results
            expiry_str = results["expiry"]
            print(f"Expiry string for user {user_id}: {expiry_str}")  # Debugging: expiry string

            # Use the function to safely parse expiry date (without time)
            expiry_date = parse_expiry(expiry_str)

            # If parsing fails or the expiry is "N/A", skip this user
            if expiry_date is None:
                print(f"Failed to parse expiry date for user {user_id}. Skipping...")  # Debugging: failed to parse
                continue

            print(f"Parsed expiry date for user {user_id}: {expiry_date}")  # Debugging: parsed expiry date

            # Check if the expiry date is within the next 2 days (inclusive)
            time_diff = expiry_date - now
            print(f"Time difference for user {user_id}: {time_diff}")  # Debugging: time difference

            # Only proceed if the expiry date is within the next 1-2 days (positive time difference)
            if 0 < time_diff.days <= 2:
                print(f"User {user_id} needs a reminder. Expiry date: {expiry_date}")  # Debugging: reminder needed
                reminder_users.append({
                    "user_id": user_id,
                    "expiry": expiry_date
                })

        # If there are users to remind, send the reminder
        if reminder_users:
            sent_brod = 0
            not_sent = 0
            for user in reminder_users:
                try:
                    user_id = user["user_id"]
                    expiry = user["expiry"]
                    expiry_str = expiry.strftime("%d-%m-%Y")
                    message_text = f"""<b>
🚨 𝐑𝐞𝐦𝐢𝐧𝐝𝐞𝐫! 📅
━━━━━━━━━━━━━━
🔒 𝐘𝐨𝐮𝐫 𝐩𝐥𝐚𝐧 𝐰𝐢𝐥𝐥 𝐞𝐱𝐩𝐢𝐫𝐞 𝐨𝐧: {expiry_str}
⏳ 𝐓𝐡𝐞 𝐩𝐥𝐚𝐧 𝐞𝐱𝐩𝐢𝐫𝐲 𝐝𝐚𝐭𝐞 𝐢𝐬 𝐢𝐧 1 𝐝𝐚𝐲!
🎯 𝐃𝐨 /buy 𝐭𝐨 𝐫𝐞𝐧𝐞𝐰 𝐲𝐨𝐮𝐫 𝐩𝐥𝐚𝐧.

Stay connected!
                    </b>"""
                    
                    await client.send_message(user_id, message_text)
                    sent_brod += 1
                    print(f"Reminder sent to user {user_id}.")  # Debugging: reminder sent
                except Exception as e:
                    not_sent += 1
                    print(f"Failed to send reminder to {user_id}: {str(e)}")  # Debugging: failed to send

            # Send completion message to the bot owner
            done_message = f"""<b>
𝐑𝐞𝐦𝐢𝐧𝐝𝐞𝐫 𝐂𝐨𝐦𝐩𝐥𝐞𝐭𝐞𝐝 ✅
━━━━━━━━━━━━━━
𝐓𝐨𝐭𝐚𝐥 𝐔𝐬𝐞𝐫𝐬 𝐑𝐞𝐦𝐢𝐧𝐝𝐞𝐝: {sent_brod}
𝐅𝐚𝐢𝐥𝐞𝐝 𝐭𝐨 𝐑𝐞𝐦𝐢𝐧𝐝: {not_sent}
</b>"""
            await message.reply_text(done_message)
            print(f"Reminder completed. {sent_brod} users reminded, {not_sent} failed.")  # Debugging: completion message
        else:
            await message.reply_text("<b>No users found with expiring plans in the next 24 hours.</b>")
            print("No users found with expiring plans in the next 24 hours.")  # Debugging: no users found

    except Exception as e:
        # Print the error to the console instead of logging it
        print(f"Error occurred: {str(e)}")
