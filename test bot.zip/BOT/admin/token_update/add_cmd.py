import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *



@Client.on_message(filters.command("damt", [".", "/"]))
async def update_dead_amount(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(
            open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp)
            return
        try:
            new_dead_amount = str(message.text.split(" ")[1])
        except:
            new_dead_amount = str(message.reply_to_message.text)


        with open("FILES/deadsk.json", "r", encoding="UTF-8") as f:
            data = json.load(f)

        data["DEAD_AMOUNT"] = new_dead_amount

        with open("FILES/deadsk.json", "w", encoding="UTF-8") as f:
            json.dump(data, f, indent=4)

        resp = f"""<b>
𝐃𝐄𝐀𝐃 𝐀𝐌𝐎𝐔𝐍𝐓 𝐔𝐩𝐝𝐚𝐭𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥y ✅
━━━━━━━━━━━━━━
𝐍𝐄𝐖 𝐃𝐄𝐀𝐃_𝐀𝐌𝐎𝐔𝐍𝐓: {new_dead_amount}
    </b>"""
        await message.reply_text(resp)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())















@Client.on_message(filters.command("setso", [".", "/"]))
async def update_shopify_url(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(
            open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        
        # Check if user is authorized
        if user_id not in OWNER_ID:
            resp = """<b>Privilege Not Found ⚠️

Message: To Perform This Action, You Need Admin Level Power. 

Contact @SPYxSPYDE For More Info ✅</b>"""
            await message.reply_text(resp)
            return

        # Extract the new URL
        if message.reply_to_message and message.reply_to_message.text:
            new_url_so = message.reply_to_message.text.strip()
        else:
            try:
                new_url_so = message.text.split(" ", 1)[1].strip()
            except IndexError:
                await message.reply_text(
                    "<b>Error ⚠️: Please reply to a message containing the URL or pass the URL directly with the command.</b>"
                )
                return

        # Update the JSON file
        with open("FILES/deadsk.json", "r", encoding="UTF-8") as f:
            data = json.load(f)

        data["AUTO_SHOPIFY_SO"] = new_url_so

        with open("FILES/deadsk.json", "w", encoding="UTF-8") as f:
            json.dump(data, f, indent=4)

        # Send success response
        resp = f"""<b>
Auto Shopify URL Updated ✅
━━━━━━━━━━━━━━
NEW SITE: {new_url_so}
        </b>"""
        await message.reply_text(resp)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())




@Client.on_message(filters.command("setsh", [".", "/"]))
async def update_shopify_url(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(
            open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        
        # Check if user is authorized
        if user_id not in OWNER_ID:
            resp = """<b>Privilege Not Found ⚠️

Message: To Perform This Action, You Need Admin Level Power. 

Contact @SPYxSPYDE For More Info ✅</b>"""
            await message.reply_text(resp)
            return

        # Extract the new URL
        if message.reply_to_message and message.reply_to_message.text:
            new_url_sh = message.reply_to_message.text.strip()
        else:
            try:
                new_url_sh = message.text.split(" ", 1)[1].strip()
            except IndexError:
                await message.reply_text(
                    "<b>Error ⚠️: Please reply to a message containing the URL or pass the URL directly with the command.</b>"
                )
                return

        # Update the JSON file
        with open("FILES/deadsk.json", "r", encoding="UTF-8") as f:
            data = json.load(f)

        data["AUTO_SHOPI"] = new_url_sh

        with open("FILES/deadsk.json", "w", encoding="UTF-8") as f:
            json.dump(data, f, indent=4)

        # Send success response
        resp = f"""<b>
Auto Shopify URL Updated ✅
━━━━━━━━━━━━━━
NEW SITE: {new_url_sh}
        </b>"""
        await message.reply_text(resp)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())






















