import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("addproxy", [".", "/"]))
async def addbrod(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        # Check if the command is used in reply to a message
        if not message.reply_to_message or not message.reply_to_message.text:
            resp = "<b>𝐏𝐥𝐞𝐚𝐬𝐞 𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐚 𝐦𝐞𝐬𝐬𝐚𝐠𝐞 𝐜𝐨𝐧𝐭𝐚𝐢𝐧𝐢𝐧𝐠 𝐭𝐡𝐞 𝐩𝐫𝐨𝐱𝐲 𝐝𝐞𝐭𝐚𝐢𝐥𝐬 𝐭𝐨 𝐮𝐬𝐞 𝐭𝐡𝐢𝐬 𝐜𝐨𝐦𝐦𝐚𝐧𝐝.</b>"
            await message.reply_text(resp, message.id)
            return

        # Get the proxy details from the replied message
        proxy = str(message.reply_to_message.text)
        
        # Clear the existing file
        with open('FILES/proxy.txt', 'w', encoding="UTF-8") as f:
            f.truncate()

        # Write new proxies to the file
        with open("FILES/proxy.txt", "a", encoding="UTF-8") as f:
            f.write(proxy)

        resp = f"""<b>
𝐏𝐫𝐨𝐱𝐲 𝐀𝐝𝐝𝐞𝐝  𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━
{proxy}

𝐓𝐨𝐭𝐚𝐥 𝐏𝐫𝐨𝐱𝐲 𝐂𝐨𝐮𝐧𝐭 : {len(proxy.splitlines())}
    </b>"""
        await message.reply_text(resp, message.id)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
