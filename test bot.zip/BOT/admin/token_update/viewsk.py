import traceback, json
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from FUNC.defs import *


@Client.on_message(filters.command("viewsk", [".", "/"]))
async def viewsk(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        sks     = await getallsk()
        amt_sk  = 0
        sk_text = ""

        for sk in sks:
            amt_sk += 1
            sk_text += f"{amt_sk}.{sk}\n"
        resp = f"""<b>
𝐂𝐮𝐫𝐫𝐞𝐧𝐭 𝐒𝐊 𝐊𝐞𝐲𝐬 𝐑𝐞𝐭𝐫𝐢𝐞𝐯𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅
━━━━━━━━━━━━━━ 
{sk_text}

𝐓𝐨𝐭𝐚𝐥 𝐒𝐊 𝐀𝐦𝐨𝐮𝐧𝐭 : {len(sks)}
        </b>"""

        await message.reply_text(resp, message.id)

    except Exception as e:
        await message.reply_text(e, message.id)
        await error_log(traceback.format_exc())
