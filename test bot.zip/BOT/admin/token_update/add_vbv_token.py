import json
from pyrogram import Client, filters
from FUNC.defs import *



@Client.on_message(filters.command("addvbvtoken", [".", "/"]))
async def addbrod(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        VBV_TOKEN = str(message.reply_to_message.text).split('"dfReferenceId":"')[1].split('"')[0]
        await update_token("VBV_TOKEN", VBV_TOKEN)

        resp = f"""<b>
𝐕𝐁𝐕 𝐓𝐎𝐊𝐄𝐍 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐀𝐝𝐝𝐞𝐝 ✅
━━━━━━━━━━━━━━
{VBV_TOKEN}

𝐒𝐭𝐚𝐭𝐮𝐬: 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥
    </b>"""
        await message.reply_text(resp, message.id)

    except:
        import traceback
        await error_log(traceback.format_exc())
