import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("fr", [".", "/"]))
async def cmd_fr(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            user_id = str(message.text.split(" ")[1])
        except:
            user_id = message.reply_to_message.from_user.id

        check_premium = await getuserinfo(user_id)
        status        = str(check_premium["status"])
        if status != "PREMIUM":
            resp = f"""<b>
𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐃𝐞𝐦𝐨𝐭𝐞𝐝 ⚠️

User ID : {user_id}
𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐅𝐫𝐞𝐞

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐓𝐡𝐢𝐬 𝐮𝐬𝐞𝐫 𝐢𝐬 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐅𝐫𝐞𝐞 𝐔𝐬𝐞𝐫. 𝐍𝐨 𝐍𝐞𝐞𝐝 𝐓𝐨 𝐃𝐞𝐦𝐨𝐭𝐞 𝐀𝐠𝐚𝐢𝐧.
        </b>"""
            await message.reply_text(resp, message.id)

        else:
            await freeuser(user_id)
            resp = f"""
𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐃𝐞𝐦𝐨𝐭𝐞𝐝 ✅

User ID: {user_id}

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐃𝐞𝐦𝐨𝐭𝐞𝐝 𝐭𝐨 "𝐅𝐫𝐞𝐞" 𝐔𝐬𝐞𝐫 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲.
        """
            await message.reply_text(resp, message.id)

            user_resp = f"""<b>
𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐃𝐞𝐦𝐨𝐭𝐞𝐝 ❌
━━━━━━━━━━━━━━
● 𝐔𝐬𝐞𝐫 𝐈𝐃: {user_id}
● 𝐑𝐨𝐥𝐞: 𝐅𝐫𝐞𝐞

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐒𝐨𝐫𝐫𝐲 ! 𝐃𝐮𝐞 𝐭𝐨 𝐒𝐨𝐦𝐞 𝐒𝐮𝐬𝐩𝐢𝐜𝐢𝐨𝐮𝐬 𝐨𝐫 𝐖𝐫𝐨𝐧𝐠 𝐁𝐞𝐡𝐚𝐯𝐢𝐨𝐫 𝐘𝐨𝐮𝐫 𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐠𝐨𝐭 𝐃𝐞𝐦𝐨𝐭𝐞𝐝 𝐭𝐨 "𝐅𝐫𝐞𝐞" 𝐔𝐬𝐞𝐫.
            </b>"""
            await Client.send_message(user_id, user_resp)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())
