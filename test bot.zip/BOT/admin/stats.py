import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from FUNC.defs import *


async def getallgc():
    from mongodb import gcdb
    return gcdb.find({}, {"_id": 0})

@Client.on_message(filters.command("stats", [".", "/"]))
async def stats(Client, message):
    try:
        user_id     = str(message.from_user.id)
        OWNER_ID    = json.loads(open("FILES/config.json", "r" , encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        chats         = 0
        total_gc      = 0
        redeemed      = 0
        total_user    = 0
        free_user     = 0
        premium_user  = 0
        silver_user   = 0
        gold_user     = 0
        elite_user    = 0
        paid_user     = 0
        get_all_chats = await getallchat()
        get_all_gc    = await getallgc() 
        get_all_user  = await getallusers()

        for item in get_all_chats:
            chats += 1

        for item in get_all_gc:
            total_gc += 1
            if item["status"] == "USED":
                redeemed += 1

        for item in get_all_user:
            total_user += 1
            if item["status"] == "FREE":
                free_user += 1
            elif item["status"] == "PREMIUM":
                premium_user += 1
            elif item["status"] == "SILVER":
                silver_user += 1
            elif item["status"] == "GOLD":
                gold_user += 1
            elif item["status"] == "ELITE":
                elite_user += 1
            elif "N/A" not in item["plan"]:
                paid_user += 1

        done = f"""<b>
𝐒𝐭𝐚𝐭𝐢𝐬𝐭𝐢𝐜𝐬 ✅
━━━━━━━━━━━━━━ 
𝐓𝐨𝐭𝐚𝐥 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 : 52
𝐃𝐚𝐭𝐚𝐛𝐚𝐬𝐞 𝐓𝐲𝐩𝐞 : 𝐌𝐨𝐧𝐠𝐨𝐃𝐁
Total Registered Users : {total_user}
Total Free Users : {free_user}
Total Premium Users : {premium_user}
Total Silver Users : {silver_user}
Total Gold Users : {gold_user}
Total Elite Users : {elite_user}
Total Authorized Chat : {chats}
Total Giftcode Genarated : {total_gc}
Total Giftcode Redeemed : {redeemed}
Total Active Users Ratio : {premium_user * 3}

𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐑𝐮𝐧𝐧𝐢𝐧𝐠
𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐎𝐧 : {message.date}
    </b> """

        await message.reply_text(done, message.id)

    except:
        import traceback
        await error_log(traceback.format_exc())
