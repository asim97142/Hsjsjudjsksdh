from pyrogram import Client, filters
from FUNC.usersdb_func import *

@Client.on_message(filters.command("info", [".", "/"]))
async def cmd_info(client, message):
    try:
        user_id = str(message.from_user.id)
        regdata = await getuserinfo(user_id)
        results = str(regdata)

        if results == "None":
            resp = """<b>
⚠️ 𝐔𝐧𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐔𝐬𝐞𝐫 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐜𝐚𝐧'𝐭 𝐮𝐬𝐞 𝐦𝐞 𝐮𝐧𝐥𝐞𝐬𝐬 𝐲𝐨𝐮 𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐟𝐢𝐫𝐬𝐭.

𝐓𝐲𝐩𝐞 /𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐭𝐨 𝐜𝐨𝐧𝐭𝐢𝐧𝐮𝐞.
</b>"""
            await message.reply_text(resp)
            return

        if message.reply_to_message:
            user_info = message.reply_to_message.from_user
        else:
            user_info = message.from_user

        user_id = str(user_info.id)
        username = str(user_info.username)
        first_name = str(user_info.first_name)
        results = await getuserinfo(user_id)

        status = results["status"]
        plan = results["plan"]
        expiry = results["expiry"]
        credit = results["credit"]
        totalkey = results["totalkey"]
        reg_at = results["reg_at"]

        send_info = f"""<b>
🔍 𝐘𝐨𝐮𝐫 𝐈𝐧𝐟𝐨 ⚡
━━━━━━━━━━━━━━
👤 𝐅𝐢𝐫𝐬𝐭 𝐍𝐚𝐦𝐞: {first_name}
🆔 𝐈𝐃: <code>{user_id}</code>
📛 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞: @{username}
🔗 𝐏𝐫𝐨𝐟𝐢𝐥𝐞 𝐋𝐢𝐧𝐤: <a href="tg://user?id={user_info.id}">Profile Link</a>
🔒 𝐓𝐆 𝐑𝐞𝐬𝐭𝐫𝐢𝐜𝐭𝐢𝐨𝐧𝐬: {user_info.is_restricted}
🚨 𝐓𝐆 𝐒𝐜𝐚𝐦𝐭𝐚𝐠: {user_info.is_scam}
🌟 𝐓𝐆 𝐏𝐫𝐞𝐦𝐢𝐮𝐦: {user_info.is_premium}
📋 𝐒𝐭𝐚𝐭𝐮𝐬: {status}
💳 𝐂𝐫𝐞𝐝𝐢𝐭: {credit}
💼 𝐏𝐥𝐚𝐧: {plan}
📅 𝐏𝐥𝐚𝐧 𝐄𝐱𝐩𝐢𝐫𝐲: {expiry}
🔑 𝐊𝐞𝐲𝐬 𝐑𝐞𝐝𝐞𝐞𝐦𝐞𝐝: {totalkey}
🗓 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐀𝐭: {reg_at}
</b>"""
        await message.reply_text(send_info)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
