from FUNC.defs import *
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton


@Client.on_message(filters.command("buy", [".", "/"]))
async def cmd_buy(client, message):
    try:
        price_list = """
📝 <b>𝚂𝙿𝚈𝚡𝙲𝙷𝙺 ⚡️ 𝙿𝙻𝙰𝙽𝚂:</b>
━━━━━━━━━━━━━━
● <b>𝐒𝐭𝐚𝐫𝐭𝐞𝐫</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 1 𝙳𝚊𝚢𝚜 𝚊𝚝 <b>$1</b>

● <b>𝐒𝐢𝐥𝐯𝐞𝐫</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 15 𝙳𝚊𝚢𝚜 𝚊𝚝 <b>$15</b>

● <b>𝐆𝐨𝐥𝐝</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 1 𝙼𝚘𝚗𝚝𝚑 𝚊𝚝 <b>$20</b>

● <b>𝐂𝐮𝐬𝐭𝐨𝐦 𝐏𝐥𝐚𝐧</b> - 𝚈𝚘𝚞 𝚌𝚊𝚗 𝚋𝚞𝚢 𝚊𝚗𝚢 𝚌𝚞𝚜𝚝𝚘𝚖 𝚙𝚕𝚊𝚗 𝚊𝚋𝚘𝚟𝚎 1 𝚖𝚘𝚗𝚝𝚑...

<i>Note: All plans are available for 1, 15, or 30 days. Once your plan expires, you will need to purchase a new one to continue using our services. Please note that all purchases are non-refundable, and you cannot transfer plans to another account.</i>
        """
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="メ 𝐊𝐧𝐨𝐜𝐤 𝐀𝐝𝐦𝐢𝐧",
                        url="http://t.me/SPYxSPYDE",
                    ),
                    InlineKeyboardButton(
                        text="マ 𝐏𝐚𝐲𝐦𝐞𝐧𝐭 𝐀𝐫𝐞𝐚",
                        callback_data="show_payment_methods",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="❌ 𝐄𝐱𝐢𝐭",
                        callback_data="close_message",
                    )
                ]
            ]
        )
        await message.reply_text(price_list, reply_markup=keyboard, disable_web_page_preview=True)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_callback_query(filters.regex("show_payment_methods"))
async def show_payment_methods(client, callback_query):
    try:
        payment_info = """
📝 <b>𝐏𝐀𝐘𝐌𝐄𝐍𝐓 𝐌𝐄𝐓𝐇𝐎𝐃𝐒:</b>
━━━━━━━━━━━━━━
💰 <b>UPI</b> - <code>𝙰𝙲𝙲𝙴𝙿𝚃𝙴𝙳 𝙳𝙼 𝙵𝙾𝚁 𝚃𝙷𝙰𝚃</code>
💰 <b>BINANCE ID/PAY</b> - <code>961853167</code>

💰 <b>BTC</b> - <code>1KDW5uL86R73FJSZrhnVhsV4d2BpR91Wgr</code>

💰 <b>USDT [BEP20]</b> - <code>0xb2f8fabff95af01183119512006c681c330e5fc1</code>

<i>Note: After completing the payment, click Knock Admin, then send the transaction screenshot with your Telegram ID.</i>
        """
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📋 𝐏𝐥𝐚𝐧 𝐋𝐢𝐬𝐭",
                        callback_data="show_price_list",
                    ),
                    InlineKeyboardButton(
                        text="メ 𝐊𝐧𝐨𝐜𝐤 𝐀𝐝𝐦𝐢𝐧",
                        url="http://t.me/SPYxSPYDE",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="❌ 𝐄𝐱𝐢𝐭",
                        callback_data="close_message",
                    )
                ]
            ]
        )
        await callback_query.message.edit_text(payment_info, reply_markup=keyboard)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_callback_query(filters.regex("show_price_list"))
async def show_price_list(client, callback_query):
    try:
        price_list = """
📝 <b>𝐒𝐏𝐘𝐱𝐂𝐇𝐊⚡️ 𝐏𝐋𝐀𝐍𝐒 :</b>
━━━━━━━━━━━━━━
● <b>𝐒𝐭𝐚𝐫𝐭𝐞𝐫</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 1 𝙳𝚊𝚢𝚜 𝚊𝚝 <b>$1</b>

● <b>𝐒𝐢𝐥𝐯𝐞𝐫</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 15 𝙳𝚊𝚢𝚜 𝚊𝚝 <b>$15</b>

● <b>𝐆𝐨𝐥𝐝</b> - 𝚄𝚗𝚕𝚒𝚖𝚒𝚝𝚎𝚍 𝙲𝚛𝚎𝚍𝚒𝚝𝚜 + 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚎𝚜𝚜 𝙵𝚘𝚛 1 𝙼𝚘𝚗𝚝𝚑 𝚊𝚝 <b>$20</b>

<i>𝐍𝐨𝐭𝐞: 𝙾𝚗𝚌𝚎 𝚢𝚘𝚞𝚛 𝚙𝚕𝚊𝚗 𝚎𝚡𝚙𝚒𝚛𝚎𝚜, 𝚢𝚘𝚞 𝚠𝚒𝚕𝚕 𝚗𝚎𝚎𝚍 𝚝𝚘 𝚙𝚞𝚛𝚌𝚑𝚊𝚜𝚎 𝚊 𝚗𝚎𝚠 𝚘𝚗𝚎 𝚝𝚘 𝚌𝚘𝚗𝚝𝚒𝚗𝚞𝚎 𝚞𝚜𝚒𝚗𝚐 𝚘𝚞𝚛 𝚜𝚎𝚛𝚟𝚒𝚌𝚎𝚜. 𝙿𝚕𝚎𝚊𝚜𝚎 𝚗𝚘𝚝𝚎 𝚝𝚑𝚊𝚝 𝚊𝚕𝚕 𝚙𝚞𝚛𝚌𝚑𝚊𝚜𝚎𝚜 𝚊𝚛𝚎 𝚗𝚘𝚗-𝚛𝚎𝚏𝚞𝚗𝚍𝚊𝚋𝚕𝚎, 𝚊𝚗𝚍 𝚢𝚘𝚞 𝚌𝚊𝚗𝚗𝚘𝚝 𝚝𝚛𝚊𝚗𝚜𝚏𝚎𝚛 𝚙𝚕𝚊𝚗𝚜 𝚝𝚘 𝚊𝚗𝚘𝚝𝚑𝚎𝚛 𝚊𝚌𝚌𝚘𝚞𝚗𝚝.</i>
        """
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="メ 𝐊𝐧𝐨𝐜𝐤 𝐀𝐝𝐦𝐢𝐧",
                        url="http://t.me/SPYxSPYDE",
                    ),
                    InlineKeyboardButton(
                        text="💳 𝐏𝐚𝐲𝐦𝐞𝐧𝐭 𝐀𝐫𝐞𝐚",
                        callback_data="show_payment_methods",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="❌ 𝐄𝐱𝐢𝐭",
                        callback_data="close_message",
                    )
                ]
            ]
        )
        await callback_query.message.edit_text(price_list, reply_markup=keyboard)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_callback_query(filters.regex("close_message"))
async def close_message(client, callback_query):
    try:
        await callback_query.message.delete()
        await callback_query.message.reply_text("🅴🅽🅹🅾🆈 🅱🆄🅳🅳🆈")

    except Exception:
        import traceback
        await error_log(traceback.format_exc())
