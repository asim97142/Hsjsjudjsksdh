from FUNC.defs import *
from pyrogram import Client, filters
import time


@Client.on_message(filters.command("ping", [".", "/"]))
async def cmd_ping(client, message):
    try:
        start = time.perf_counter()
        resp  = """<b>
🤖 𝐂𝐡𝐞𝐜𝐤𝐢𝐧𝐠 𝐒𝐏𝐘𝐱𝐂𝐇𝐊 ⚡ 𝐏𝐢𝐧𝐠...
        </b>"""
        edit  = await message.reply_text(resp, quote=True)
        end   = time.perf_counter()
        
        textb = f"""<b>
🤖 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞: 𝐒𝐏𝐘𝐱𝐂𝐇𝐊 ⚡
✅ 𝐁𝐨𝐭 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐑𝐮𝐧𝐧𝐢𝐧𝐠
📶 𝐏𝐢𝐧𝐠: {(end-start)*1000:.2f} 𝐦𝐬
        </b>"""
        await client.edit_message_text(message.chat.id, edit.id, textb)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())
