import asyncio
import time
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from FUNC.defs import *
from FUNC.usersdb_func import *


@Client.on_message(filters.command("cmds", [".", "/"]))
async def cmd_scr(client, message):
    try:
        WELCOME_TEXT = f"""
<b>🅷🅴🅻🅻🅾 <a href="tg://user?id={message.from_user.id}"> {message.from_user.first_name}</a> !

𝐒𝐏𝐘𝐱𝐂𝐇𝐊 𝐇𝐚𝐬 𝐩𝐥𝐞𝐧𝐭𝐲 𝐨𝐟 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬. 𝐖𝐞 𝐇𝐚𝐯𝐞 𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬, 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬, 𝐓𝐨𝐨𝐥𝐬 𝐀𝐧𝐝 𝐎𝐭𝐡𝐞𝐫 𝐓𝐡𝐢𝐧𝐠𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐄𝐚𝐜𝐡 𝐨𝐟 𝐓𝐡𝐞𝐦 𝐁𝐞𝐥𝐨𝐰 𝐭𝐨 𝐊𝐧𝐨𝐰 𝐓𝐡𝐞𝐦 𝐁𝐞𝐭𝐭𝐞𝐫.</b>
        """
        WELCOME_BUTTONS = [
            [
                InlineKeyboardButton("𝐀𝐔𝐓𝐇/𝐁3/𝐕𝐁𝐕", callback_data="AUTH"),
                InlineKeyboardButton("𝐂𝐇𝐀𝐑𝐆𝐄", callback_data="CHARGE")
            ],
            [
                InlineKeyboardButton("𝐓𝐎𝐎𝐋𝐒", callback_data="TOOLS"),
                InlineKeyboardButton("𝐇𝐄𝐋𝐏𝐄𝐑", callback_data="HELPER")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await message.reply(
            text=WELCOME_TEXT,
            reply_markup=InlineKeyboardMarkup(WELCOME_BUTTONS))

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


async def callback_command(client, message):
    try:
        WELCOME_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫 !

𝐒𝐏𝐘𝐱𝐂𝐇𝐊 𝐇𝐚𝐬 𝐩𝐥𝐞𝐧𝐭𝐲 𝐨𝐟 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬. 𝐖𝐞 𝐇𝐚𝐯𝐞 𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬, 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬, 𝐓𝐨𝐨𝐥𝐬 𝐀𝐧𝐝 𝐎𝐭𝐡𝐞𝐫 𝐓𝐡𝐢𝐧𝐠𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐄𝐚𝐜𝐡 𝐨𝐟 𝐓𝐡𝐞𝐦 𝐁𝐞𝐥𝐨𝐰 𝐭𝐨 𝐊𝐧𝐨𝐰 𝐓𝐡𝐞𝐦 𝐁𝐞𝐭𝐭𝐞𝐫.</b>
        """
        WELCOME_BUTTONS = [
            [
                InlineKeyboardButton("𝐀𝐔𝐓𝐇/𝐁3/𝐕𝐁𝐕", callback_data="AUTH"),
                InlineKeyboardButton("𝐂𝐇𝐀𝐑𝐆𝐄", callback_data="CHARGE")
            ],
            [
                InlineKeyboardButton("𝐓𝐎𝐎𝐋𝐒", callback_data="TOOLS"),
                InlineKeyboardButton("𝐇𝐄𝐋𝐏𝐄𝐑", callback_data="HELPER")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await message.reply(
            text=WELCOME_TEXT,
            reply_markup=InlineKeyboardMarkup(WELCOME_BUTTONS))

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_message(filters.command("start", [".", "/"]))
async def cmd_start(Client, message):
    try:
        text = """<b>
𝙎𝙋𝙔𝙭𝘾𝙃𝙆 ■□□
      </b>"""
        edit = await message.reply_text(text, message.id)
        await asyncio.sleep(0.5)

        text = """<b>
𝙎𝙋𝙔𝙭𝘾𝙃𝙆 ■■■
     </b> """
        edit = await Client.edit_message_text(message.chat.id, edit.id, text)
        await asyncio.sleep(0.5)

        text = f"""
<b>🌟 𝙃𝙚𝙡𝙡𝙤 <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>!</b>

<b>𝙒𝙚𝙡𝙘𝙤𝙢𝙚 𝙖𝙗𝙤𝙖𝙧𝙙 𝙩𝙝𝙚 𝙎𝙋𝙔𝙭𝘾𝙃𝙆!🚀</b>

<b>𝙄 𝙖𝙢 𝙮𝙤𝙪𝙧 𝙜𝙤-𝙩𝙤 𝙗𝙤𝙩, 𝙥𝙖𝙘𝙠𝙚𝙙 𝙬𝙞𝙩𝙝 𝙖 𝙫𝙖𝙧𝙞𝙚𝙩𝙮 𝙤𝙛 𝙜𝙖𝙩𝙚𝙨, 𝙩𝙤𝙤𝙡𝙨, 𝙖𝙣𝙙 𝙘𝙤𝙢𝙢𝙖𝙣𝙙𝙨 𝙩𝙤 𝙚𝙣𝙝𝙖𝙣𝙘𝙚 𝙮𝙤𝙪𝙧 𝙚𝙭𝙥𝙚𝙧𝙞𝙚𝙣𝙘𝙚. 𝙀𝙭𝙘𝙞𝙩𝙚𝙙 𝙩𝙤 𝙨𝙚𝙚 𝙬𝙝𝙖𝙩 𝙄 𝙘𝙖𝙣 𝙙𝙤?</b>

<b>👇 𝙏𝙖𝙥 𝙩𝙝𝙚 <i>Register</i> 𝙗𝙪𝙩𝙩𝙤𝙣 𝙩𝙤 𝙗𝙚𝙜𝙞𝙣 𝙮𝙤𝙪𝙧 𝙟𝙤𝙪𝙧𝙣𝙚𝙮.</b>
<b>👇 𝘿𝙞𝙨𝙘𝙤𝙫𝙚𝙧 𝙢𝙮 𝙛𝙪𝙡𝙡 𝙘𝙖𝙥𝙖𝙗𝙞𝙡𝙞𝙩𝙞𝙚𝙨 𝙗𝙮 𝙩𝙖𝙥𝙥𝙞𝙣𝙜 𝙩𝙝𝙚 <i>Commands</i> 𝙗𝙪𝙩𝙩𝙤𝙣.</b>

"""
        WELCOME_BUTTON = [
            [
                InlineKeyboardButton("𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫", callback_data="register"),
                InlineKeyboardButton("𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬", callback_data="cmds")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await Client.edit_message_text(message.chat.id, edit.id, text, reply_markup=InlineKeyboardMarkup(WELCOME_BUTTON))

    except:
        import traceback
        await error_log(traceback.format_exc())


async def register_user(user_id, username, antispam_time, reg_at):
    info = {
        "id": f"{user_id}",
        "username": f"{username}",
        "user_proxy":f"N/A",
        "dcr": "N/A",
        "dpk": "N/A",
        "dsk": "N/A",
        "amt": "N/A",
        "status": "FREE",
        "plan": f"N/A",
        "expiry": "N/A",
        "credit": "100",
        "antispam_time": f"{antispam_time}",
        "totalkey": "0",
        "reg_at": f"{reg_at}",
    }
    usersdb.insert_one(info)


@Client.on_message(filters.command("register", [".", "/"]))
async def cmd_register(Client, message):
    try:
        user_id = str(message.from_user.id)
        username = str(message.from_user.username)
        antispam_time = int(time.time())
        yy, mm, dd = str(date.today()).split("-")
        reg_at = f"{dd}-{mm}-{yy}"
        find = usersdb.find_one({"id": f"{user_id}"}, {"_id": 0})
        registration_check = str(find)

        WELCOME_BUTTON = [
            [
                InlineKeyboardButton("𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬", callback_data="cmds")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        if registration_check == "None":
            await register_user(user_id, username, antispam_time, reg_at)
            resp = f"""<b>
𝐑𝐞𝐠𝐢𝐬𝐭𝐫𝐚𝐭𝐢𝐨𝐧 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥 ♻️
━━━━━━━━━━━━━━
● 𝐍𝐚𝐦𝐞: {message.from_user.first_name}
● 𝐔𝐬𝐞𝐫 𝐈𝐃: {message.from_user.id}
● 𝐑𝐨𝐥𝐞: 𝐅𝐫𝐞𝐞
● 𝐂𝐫𝐞𝐝𝐢𝐭𝐬: 100

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐆𝐨𝐭 100 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐚𝐬 𝐚 𝐫𝐞𝐠𝐢𝐬𝐭𝐫𝐚𝐭𝐢𝐨𝐧 𝐛𝐨𝐧𝐮𝐬. 𝐓𝐨 𝐊𝐧𝐨𝐰 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐒𝐲𝐬𝐭𝐞𝐦 /howcrd.

𝐄𝐱𝐩𝐥𝐨𝐫𝐞 𝐌𝐲 𝐕𝐚𝐫𝐢𝐨𝐮𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐀𝐧𝐝 𝐀𝐛𝐢𝐥𝐢𝐭𝐢𝐞𝐬 𝐁𝐲 𝐓𝐚𝐩𝐩𝐢𝐧𝐠 𝐨𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐁𝐮𝐭𝐭𝐨𝐧.  
            </b>"""

        else:
            resp = f"""<b>
𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐢𝐧 𝐨𝐮𝐫 𝐛𝐨𝐭. 𝐍𝐨 𝐧𝐞𝐞𝐝 𝐭𝐨 𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐧𝐨𝐰.

𝐄𝐱𝐩𝐥𝐨𝐫𝐞 𝐌𝐲 𝐕𝐚𝐫𝐢𝐨𝐮𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐀𝐧𝐝 𝐀𝐛𝐢𝐥𝐢𝐭𝐢𝐞𝐬 𝐁𝐲 𝐓𝐚𝐩𝐩𝐢𝐧𝐠 𝐨𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐁𝐮𝐭𝐭𝐨𝐧. 
            </b>"""

        await message.reply_text(resp, reply_markup=InlineKeyboardMarkup(WELCOME_BUTTON))

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


async def callback_register(Client, message):
    try:
        user_id = str(message.reply_to_message.from_user.id)
        username = str(message.reply_to_message.from_user.username)
        antispam_time = int(time.time())
        yy, mm, dd = str(date.today()).split("-")
        reg_at = f"{dd}-{mm}-{yy}"
        find = usersdb.find_one({"id": f"{user_id}"}, {"_id": 0})
        registration_check = str(find)

        WELCOME_BUTTON = [
            [
                InlineKeyboardButton("𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬", callback_data="cmds")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        if registration_check == "None":
            await register_user(user_id, username, antispam_time, reg_at)
            resp = f"""<b>
𝐑𝐞𝐠𝐢𝐬𝐭𝐫𝐚𝐭𝐢𝐨𝐧 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥 ♻️
━━━━━━━━━━━━━━
● 𝐍𝐚𝐦𝐞: {message.reply_to_message.from_user.first_name}
● 𝐔𝐬𝐞𝐫 𝐈𝐃: {user_id}
● 𝐑𝐨𝐥𝐞: 𝐅𝐫𝐞𝐞
● 𝐂𝐫𝐞𝐝𝐢𝐭𝐬: 100

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐆𝐨𝐭 100 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐚𝐬 𝐚 𝐫𝐞𝐠𝐢𝐬𝐭𝐫𝐚𝐭𝐢𝐨𝐧 𝐛𝐨𝐧𝐮𝐬. 𝐓𝐨 𝐊𝐧𝐨𝐰 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐒𝐲𝐬𝐭𝐞𝐦 /howcrd.

𝐄𝐱𝐩𝐥𝐨𝐫𝐞 𝐌𝐲 𝐕𝐚𝐫𝐢𝐨𝐮𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐀𝐧𝐝 𝐀𝐛𝐢𝐥𝐢𝐭𝐢𝐞𝐬 𝐁𝐲 𝐓𝐚𝐩𝐩𝐢𝐧𝐠 𝐨𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐁𝐮𝐭𝐭𝐨𝐧. 
            </b>"""

        else:
            resp = f"""<b>
𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐚𝐫𝐞 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐢𝐧 𝐨𝐮𝐫 𝐛𝐨𝐭. 𝐍𝐨 𝐧𝐞𝐞𝐝 𝐭𝐨 𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐧𝐨𝐰.

𝐄𝐱𝐩𝐥𝐨𝐫𝐞 𝐌𝐲 𝐕𝐚𝐫𝐢𝐨𝐮𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐀𝐧𝐝 𝐀𝐛𝐢𝐥𝐢𝐭𝐢𝐞𝐬 𝐁𝐲 𝐓𝐚𝐩𝐩𝐢𝐧𝐠 𝐨𝐧 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐁𝐮𝐭𝐭𝐨𝐧. 
            </b>"""

        await message.reply_text(resp, message.id, reply_markup=InlineKeyboardMarkup(WELCOME_BUTTON))

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_callback_query()
@Client.on_callback_query()
async def callback_query(Client, CallbackQuery):
    if CallbackQuery.data == "cmds":
        await callback_command(Client, CallbackQuery.message)

    if CallbackQuery.data == "register":
        await callback_register(Client, CallbackQuery.message)

    if CallbackQuery.data == "HOME":
        WELCOME_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫!

𝐌𝐀𝐒𝐓𝐄𝐑 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐇𝐚𝐬 𝐩𝐥𝐞𝐧𝐭𝐲 𝐨𝐟 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬. 𝐖𝐞 𝐇𝐚𝐯𝐞 𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬, 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬, 𝐓𝐨𝐨𝐥𝐬, 𝐀𝐧𝐝 𝐎𝐭𝐡𝐞𝐫 𝐓𝐡𝐢𝐧𝐠𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐄𝐚𝐜𝐡 𝐨𝐟 𝐓𝐡𝐞𝐦 𝐁𝐞𝐥𝐨𝐰 𝐭𝐨 𝐊𝐧𝐨𝐰 𝐓𝐡𝐞𝐦 𝐁𝐞𝐭𝐭𝐞𝐫.</b>
    """
        WELCOME_BUTTONS = [
            [
                InlineKeyboardButton("𝐀𝐔𝐓𝐇/𝐁3/𝐕𝐁𝐕", callback_data="AUTH"),
                InlineKeyboardButton("𝐂𝐇𝐀𝐑𝐆𝐄", callback_data="CHARGE")
            ],
            [
                InlineKeyboardButton("𝐓𝐎𝐎𝐋𝐒", callback_data="TOOLS"),
                InlineKeyboardButton("𝐇𝐄𝐋𝐏𝐄𝐑", callback_data="HELPER")
            ],
            [
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=WELCOME_TEXT,
            reply_markup=InlineKeyboardMarkup(WELCOME_BUTTONS))

    if CallbackQuery.data == "close":
        await CallbackQuery.message.delete()
        await CallbackQuery.message.reply_text("𝐄𝐍𝐉𝐎𝐘 𝐁𝐔𝐃𝐃𝐘 🧡")


    if CallbackQuery.data == "AUTH":
        AUTH_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫!

𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐨𝐧 𝐞𝐚𝐜𝐡 𝐨𝐧𝐞 𝐛𝐞𝐥𝐨𝐰 𝐭𝐨 𝐠𝐞𝐭 𝐭𝐨 𝐤𝐧𝐨𝐰 𝐭𝐡𝐞𝐦 𝐛𝐞𝐭𝐭𝐞𝐫...</b>
    """
        AUTH_BUTTONS = [
            [
                InlineKeyboardButton("ㇿ𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐮𝐭𝐡ㇿ", callback_data="Auth2"),
                # InlineKeyboardButton("Adyen Auth", callback_data="Adyen2"),
            ],
            [
                InlineKeyboardButton(
                    "ㇿ𝐁3 𝐀𝐮𝐭𝐡ㇿ", callback_data="BRAINTREEB3"),

                InlineKeyboardButton(
                    "ㇿ𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐕𝐁𝐕ㇿ", callback_data="BRAINTREEVBV"),
            ],
            [
                InlineKeyboardButton("Back", callback_data="HOME"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=AUTH_TEXT,
            reply_markup=InlineKeyboardMarkup(AUTH_BUTTONS))
    if CallbackQuery.data == "Auth2":
        CHARGE_TEXT = """
[ぁ] 𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬
[ぁ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

 ~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぁ] 𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐮𝐭𝐡 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐒𝐢𝐭𝐞-𝐁𝐚𝐬𝐞𝐝 𝐀𝐮𝐭𝐡:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐚𝐮 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐚𝐬𝐬 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 1

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="AUTH"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "Adyen2":
        CHARGE_TEXT = """
[ぁ] 𝐀𝐝𝐲𝐞𝐧 𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐬
[ぁ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐈𝐧𝐚𝐜𝐭𝐢𝐯𝐞 ❌

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぁ] 𝐀𝐝𝐲𝐞𝐧 𝐀𝐮𝐭𝐡 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐀𝐝𝐲𝐞𝐧 𝐀𝐮𝐭𝐡:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐚𝐝 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐚𝐬𝐬𝐚𝐝 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 1

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="AUTH"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "BRAINTREEVBV":
        CHARGE_TEXT = """
[ぁ] 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐆𝐚𝐭𝐞𝐬
[ぁ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぁ] 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐕𝐁𝐕 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐕𝐁𝐕 𝐋𝐨𝐨𝐤𝐮𝐩 𝐆𝐚𝐭𝐞:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐯𝐛𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬 (𝐋𝐢𝐦𝐢𝐭=25): /𝐦𝐯𝐛𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 1

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="AUTH"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )

    if CallbackQuery.data == "BRAINTREEB3":
        CHARGE_TEXT = """
[ぁ] 𝐁3 𝐀𝐮𝐭𝐡
[ぁ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぁ] 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐁3 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐁3 𝐆𝐚𝐭𝐞:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐛3 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬 (𝐋𝐢𝐦𝐢𝐭=5): /𝐦𝐛3 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅

𝐓𝐨𝐭𝐚𝐥 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 1

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="AUTH"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )





    if CallbackQuery.data == "CHARGE":
        CHARGE_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫!

𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐨𝐧 𝐞𝐚𝐜𝐡 𝐨𝐧𝐞 𝐛𝐞𝐥𝐨𝐰 𝐭𝐨 𝐠𝐞𝐭 𝐭𝐨 𝐤𝐧𝐨𝐰 𝐭𝐡𝐞𝐦 𝐛𝐞𝐭𝐭𝐞𝐫...</b>
    """
        
        CHARGE_BUTTONS = [
            [
                InlineKeyboardButton("𝐒𝐊 𝐁𝐚𝐬𝐞𝐝", callback_data="SKBASED"),
                InlineKeyboardButton("𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞", callback_data="BRAINTREE"),
            ],
            [
                InlineKeyboardButton("𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐩𝐢", callback_data="SITE"),
                InlineKeyboardButton("𝐒𝐡𝐨𝐩𝐢𝐟𝐲", callback_data="SHOPIFY"),
            ],
            # [
            #     InlineKeyboardButton("Paypal", callback_data="PAYPAL"),
            # ],
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="HOME"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTONS))
    if CallbackQuery.data == "PAYPAL":
        CHARGE_TEXT = """
 𝙋𝙖𝙮𝙋𝙖𝙡 𝘾𝙝𝙖𝙧𝙜𝙚 𝙂𝙖𝙩𝙚𝙨
 𝙎𝙩𝙖𝙩𝙪𝙨: 𝙄𝙣𝙖𝙘𝙩𝙞𝙫𝙚 ❌

 𝙌𝙪𝙞𝙘𝙠 𝘾𝙤𝙢𝙢𝙖𝙣𝙙𝙨 𝙊𝙫𝙚𝙧𝙫𝙞𝙚𝙬:

 𝙋𝙖𝙮𝙋𝙖𝙡 𝘾𝙝𝙖𝙧𝙜𝙚 𝙊𝙥𝙩𝙞𝙤𝙣𝙨:
    1. 𝙋𝙖𝙮𝙋𝙖𝙡 𝘾𝙝𝙖𝙧𝙜𝙚 0.1$:
        ➜ 𝙎𝙞𝙣𝙜𝙡𝙚: /𝙥𝙥 𝙘𝙘|𝙢𝙢|𝙮𝙮|𝙘𝙫𝙫 ❌
        ➜ 𝙈𝙖𝙨𝙨: /𝙢𝙥𝙥 𝙘𝙘|𝙢𝙢|𝙮𝙮|𝙘𝙫𝙫 ❌

    2. 𝙋𝙖𝙮𝙋𝙖𝙡 𝘾𝙝𝙖𝙧𝙜𝙚 1.50$:
        ➜ 𝙎𝙞𝙣𝙜𝙡𝙚: /𝙥𝙮 𝙘𝙘|𝙢𝙢|𝙮𝙮|𝙘𝙫𝙫 ❌ 
        ➜ 𝙈𝙖𝙨𝙨: /𝙢𝙥𝙮 𝙘𝙘|𝙢𝙢|𝙮𝙮|𝙘𝙫𝙫 ❌

𝙏𝙤𝙩𝙖𝙡 𝘼𝙪𝙩𝙝 𝘾𝙤𝙢𝙢𝙖𝙣𝙙𝙨: 2

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="CHARGE"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )  


    if CallbackQuery.data == "SKBASED":
        CHARGE_TEXT = """
[ぞ] 𝐒𝐊 𝐁𝐚𝐬𝐞𝐝 𝐆𝐚𝐭𝐞𝐬
[ぞ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぞ] 𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐒𝐊 𝐁𝐀𝐒𝐄𝐃 𝐂𝐇𝐀𝐑𝐆𝐄 0.5$ 𝐂𝐕𝐕:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐬𝐯𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐬𝐯𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬 𝐭𝐱𝐭 (𝐋𝐢𝐦𝐢𝐭=3𝐤): /𝐬𝐯𝐯𝐭𝐱𝐭 [𝐢𝐧 𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐟𝐢𝐥𝐞] ✅ 
        ➜ 𝐒𝐞𝐥𝐟 𝐒𝐊 𝐚𝐥𝐬𝐨 𝐚𝐝𝐝𝐞𝐝, 𝐜𝐡𝐞𝐜𝐤: /𝐬𝐞𝐥𝐟𝐜𝐦𝐝 ✅

    2. 𝐒𝐊 𝐁𝐀𝐒𝐄𝐃 0.5$ 𝐂𝐂𝐍 𝐂𝐇𝐀𝐑𝐆𝐄:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐜𝐜𝐧 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐜𝐜𝐧 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬 𝐭𝐱𝐭 (𝐋𝐢𝐦𝐢𝐭=3𝐤): /𝐜𝐜𝐧𝐭𝐱𝐭 [𝐢𝐧 𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐟𝐢𝐥𝐞] ✅
        ➜ 𝐒𝐞𝐥𝐟 𝐒𝐊 𝐚𝐥𝐬𝐨 𝐚𝐝𝐝𝐞𝐝, 𝐜𝐡𝐞𝐜𝐤: /𝐬𝐞𝐥𝐟𝐜𝐦𝐝 ✅

    3. 𝐒𝐊 𝐁𝐀𝐒𝐄𝐃 0.5$ 𝐂𝐕𝐕 𝐂𝐇𝐀𝐑𝐆𝐄:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐜𝐯𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐜𝐯𝐯 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
        ➜ 𝐌𝐚𝐬𝐬 𝐭𝐱𝐭 (𝐋𝐢𝐦𝐢𝐭=3𝐤): /𝐜𝐯𝐯𝐭𝐱𝐭 [𝐢𝐧 𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐟𝐢𝐥𝐞] ✅
        ➜ 𝐒𝐞𝐥𝐟 𝐒𝐊 𝐚𝐥𝐬𝐨 𝐚𝐝𝐝𝐞𝐝, 𝐜𝐡𝐞𝐜𝐤: /𝐬𝐞𝐥𝐟𝐜𝐦𝐝 ✅

𝐓𝐨𝐭𝐚𝐥 𝐂𝐡𝐚𝐫𝐠𝐞 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 3

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="CHARGE"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "SITE":
        CHARGE_TEXT = """
[ぞ] 𝐒𝐢𝐭𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬
[ぞ] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[ぞ] 𝐒𝐢𝐭𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
1. 𝐒𝐈𝐓𝐄𝐁𝐀𝐒𝐄 2$ 𝐂𝐕𝐕 𝐂𝐇𝐀𝐑𝐆𝐄:
➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐜𝐡𝐤 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
➜ 𝐌𝐚𝐬𝐬: /𝐦𝐜𝐡𝐤 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

1. 𝐒𝐈𝐓𝐄𝐁𝐀𝐒𝐄 1£ 𝐂𝐇𝐀𝐑𝐆𝐄:
➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐜𝐜 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
➜ 𝐌𝐚𝐬𝐬: /𝐜𝐜𝐬 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ✅
➜ 𝐓𝐱𝐭: /𝐜𝐜𝐭𝐱𝐭 (𝐂𝐡𝐞𝐜𝐤 𝐓𝐱𝐭 𝐅𝐢𝐥𝐞) ❌

𝐓𝐨𝐭𝐚𝐥 𝐂𝐡𝐚𝐫𝐠𝐞 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 2

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="CHARGE"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "BRAINTREE":
        CHARGE_TEXT = """
[が] 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬
[が] 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐈𝐧𝐀𝐜𝐭𝐢𝐯𝐞 ❌

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[が] 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 1£:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐛𝐫 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐛𝐫 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 1

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="CHARGE"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "SHOPIFY":
        CHARGE_TEXT = """

 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 𝐆𝐚𝐭𝐞𝐬
 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐈𝐧𝐀𝐜𝐭𝐢𝐯𝐞 ❌

 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 𝐎𝐩𝐭𝐢𝐨𝐧𝐬:
    1. 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 10$:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐬𝐡 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐬𝐡 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

    2. 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 27.51$:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐬𝐨 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐬𝐨 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

    3. 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 20$:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐬𝐡𝐨 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐬𝐡𝐨 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

    4. 𝐒𝐡𝐨𝐩𝐢𝐟𝐲 𝐂𝐡𝐚𝐫𝐠𝐞 15$:
        ➜ 𝐒𝐢𝐧𝐠𝐥𝐞: /𝐬𝐠 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌
        ➜ 𝐌𝐚𝐬𝐬: /𝐦𝐬𝐠 𝐜𝐜|𝐦𝐦|𝐲𝐲|𝐜𝐯𝐯 ❌

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 4

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="CHARGE"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "TOOLS":
        TOOLS_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫!

𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐓𝐨𝐨𝐥𝐬.

𝐂𝐥𝐢𝐜𝐤 𝐨𝐧 𝐞𝐚𝐜𝐡 𝐨𝐧𝐞 𝐛𝐞𝐥𝐨𝐰 𝐭𝐨 𝐠𝐞𝐭 𝐭𝐨 𝐤𝐧𝐨𝐰 𝐭𝐡𝐞𝐦 𝐛𝐞𝐭𝐭𝐞𝐫..</b>
    """
        CHARGE_BUTTONS = [
            [
                InlineKeyboardButton("𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐫", callback_data="SCRAPPER"),
                InlineKeyboardButton("𝐒𝐊 𝐓𝐎𝐎𝐋𝐒", callback_data="SKSTOOL"),
            ],
            [
                InlineKeyboardButton(
                    "𝐆𝐞𝐧e𝐫𝐚𝐭𝐨𝐫", callback_data="GENARATORTOOLS"),
                InlineKeyboardButton(
                    "𝐁𝐢𝐧 & 𝐎𝐭𝐡𝐞𝐫𝐬", callback_data="BINANDOTHERS"),
            ],
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="HOME"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=TOOLS_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTONS))

    if CallbackQuery.data == "SKSTOOL":
        CHARGE_TEXT = """
[が] 𝐒𝐊 𝐓𝐨𝐨𝐥𝐬
[が] 𝐒𝐭𝐚𝐭𝐮𝐬:  𝐀𝐜𝐭𝐢𝐯𝐞

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

[が] 𝐒𝐊 𝐓𝐨𝐨𝐥𝐬:
    1. 𝐒𝐊 𝐊𝐞𝐲 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐤 𝐬𝐤_𝐥𝐢𝐯𝐞_𝐱𝐱𝐱𝐱𝐱𝐱  (𝐋𝐢𝐦𝐢𝐭: 𝐒𝐢𝐧𝐠𝐥𝐞) ✅
    2. 𝐒𝐊 𝐓𝐨 𝐏𝐊 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐆𝐚𝐭𝐞: /𝐩𝐤 𝐬𝐤_𝐥𝐢𝐯𝐞_𝐱𝐱𝐱𝐱𝐱𝐱  (𝐋𝐢𝐦𝐢𝐭: 𝐒𝐢𝐧𝐠𝐥𝐞) ✅
    3. 𝐒𝐊 𝐔𝐬𝐞𝐫 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐤𝐮𝐬𝐞𝐫 𝐬𝐤_𝐥𝐢𝐯𝐞_𝐱𝐱𝐱𝐱𝐱𝐱  (𝐋𝐢𝐦𝐢𝐭: 𝐒𝐢𝐧𝐠𝐥𝐞) ✅
    4. 𝐒𝐊 𝐈𝐧𝐟𝐨 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐤𝐢𝐧𝐟𝐨 𝐬𝐤_𝐥𝐢𝐯𝐞_𝐱𝐱𝐱𝐱𝐱𝐱  (𝐋𝐢𝐦𝐢𝐭: 𝐒𝐢𝐧𝐠𝐥𝐞) ✅

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 4

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="TOOLS"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "SCRAPPER":
        CHARGE_TEXT = """
㋼ 𝐒𝐜𝐫𝐚𝐩𝐩𝐞𝐫 𝐓𝐨𝐨𝐥𝐬 𝐆𝐚𝐭𝐞𝐬
㋼ 𝐒𝐭𝐚𝐭𝐮𝐬: 𝐀𝐜𝐭𝐢𝐯𝐞 ✅

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

㋼ 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 𝐓𝐨𝐨𝐥𝐬:
    1. 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐜𝐫 𝐜𝐡𝐚𝐧𝐧𝐞𝐥_𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 100 ✅ (𝐋𝐢𝐦𝐢𝐭: 5𝐊)
    2. 𝐁𝐢𝐧 𝐁𝐚𝐬𝐞𝐝 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐜𝐫𝐛𝐢𝐧 440393 𝐜𝐡𝐚𝐧𝐧𝐞𝐥_𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 100 ✅ (𝐋𝐢𝐦𝐢𝐭: 5𝐊)
    3. 𝐒𝐊 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐬𝐜𝐫𝐬𝐤 𝐜𝐡𝐚𝐧𝐧𝐞𝐥_𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 100 ✅ (𝐋𝐢𝐦𝐢𝐭: 5𝐊)

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 3

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="TOOLS"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "GENARATORTOOLS":
        CHARGE_TEXT = """
㋼ 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐓𝐨𝐨𝐥𝐬
㋼ 𝐒𝐭𝐚𝐭𝐮𝐬: ✅ 𝐀𝐜𝐭𝐢𝐯𝐞

 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

㋼ 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐓𝐨𝐨𝐥𝐬:
    1. 𝐑𝐚𝐧𝐝𝐨𝐦 𝐂𝐂 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐆𝐚𝐭𝐞: /𝐠𝐞𝐧 440393 500  (𝐋𝐢𝐦𝐢𝐭: 10𝐤) ✅
    2. 𝐅𝐚𝐤𝐞 𝐀𝐝𝐝𝐫𝐞𝐬𝐬 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫 𝐆𝐚𝐭𝐞: /𝐟𝐚𝐤𝐞 𝐮𝐬 ❌

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 2

"""
        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("Back", callback_data="TOOLS"),
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
    if CallbackQuery.data == "BINANDOTHERS":
        CHARGE_TEXT = """
㋼ 𝐁𝐢𝐧 𝐚𝐧𝐝 𝐎𝐭𝐡𝐞𝐫 𝐓𝐨𝐨𝐥𝐬
㋼ 𝐒𝐭𝐚𝐭𝐮𝐬: ✅ 𝐀𝐜𝐭𝐢𝐯𝐞

~ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

㋼ 𝐁𝐈𝐍 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧:
    1. 𝐁𝐈𝐍 𝐈𝐧𝐟𝐨 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐛𝐢𝐧 440393  (𝐒𝐢𝐧𝐠𝐥𝐞 𝐋𝐢𝐦𝐢𝐭) ✅
    2. 𝐓𝐞𝐱𝐭 𝐓𝐨 𝐂𝐂 𝐅𝐢𝐥𝐭𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐟𝐥 [𝐢𝐧 𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐭𝐞𝐱𝐭] ✅
    3. 𝐌𝐚𝐬𝐬 𝐁𝐈𝐍 𝐈𝐧𝐟𝐨 𝐂𝐡𝐞𝐜𝐤𝐞𝐫 𝐆𝐚𝐭𝐞: /𝐦𝐚𝐬𝐬𝐛𝐢𝐧 440393  (𝐋𝐢𝐦𝐢𝐭: 30) ✅

 𝐀𝐝𝐝𝐢𝐭𝐢𝐨𝐧𝐚𝐥 𝐓𝐨𝐨𝐥𝐬:
    4. 𝐈𝐏 𝐋𝐨𝐨𝐤𝐮𝐩 𝐆𝐚𝐭𝐞: /𝐢𝐩 𝐲𝐨𝐮𝐫_𝐢𝐩 ✅
    5. 𝐆𝐚𝐭𝐞𝐰𝐚𝐲𝐬 𝐇𝐮𝐧𝐭𝐞𝐫: /𝐮𝐫𝐥 𝐰𝐞𝐛𝐬𝐢𝐭𝐞_𝐮𝐫𝐥  (𝐋𝐢𝐦𝐢𝐭: 100) ✅
    6. 𝐆𝐏𝐓-4: /𝐠𝐩𝐭 𝐏𝐫𝐨𝐦𝐨𝐭𝐞 ❌

𝐓𝐨𝐭𝐚𝐥 𝐀𝐮𝐭𝐡 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 6


"""

        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="TOOLS"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )

    if CallbackQuery.data == "HELPER":
        HELPER_TEXT = f"""
<b>𝐇𝐞𝐥𝐥𝐨 𝐔𝐬𝐞𝐫!

𝐇𝐞𝐥𝐩𝐞𝐫.

𝐂𝐥𝐢𝐜𝐤 𝐨𝐧 𝐞𝐚𝐜𝐡 𝐨𝐧𝐞 𝐛𝐞𝐥𝐨𝐰 𝐭𝐨 𝐠𝐞𝐭 𝐭𝐨 𝐤𝐧𝐨𝐰 𝐭𝐡𝐞𝐦 𝐛𝐞𝐭𝐭𝐞𝐫.</b>
    """
        CHARGE_BUTTONS = [
            [
                InlineKeyboardButton("𝐇𝐞𝐥𝐩𝐞𝐫", callback_data="INFO"),
                # InlineKeyboardButton("SK TOOLS", callback_data="SKTOOLS"),
            ],
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="HOME"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=HELPER_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTONS))
    if CallbackQuery.data == "INFO":
        CHARGE_TEXT = """
㋼ 𝐇𝐞𝐥𝐩𝐞𝐫
㋼ 𝐒𝐭𝐚𝐭𝐮𝐬: ✅ 𝐀𝐜𝐭𝐢𝐯𝐞

㋼ 𝐐𝐮𝐢𝐜𝐤 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐎𝐯𝐞𝐫𝐯𝐢𝐞𝐰:

~ 𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐌𝐚𝐧𝐚𝐠𝐞𝐦𝐞𝐧𝐭:
    1. 𝐒𝐭𝐚𝐫𝐭 𝐁𝐨𝐭: /𝐬𝐭𝐚𝐫𝐭
    2. 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫: /𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫
    3. 𝐔𝐬𝐞𝐫 𝐈𝐃: /𝐢𝐝
    4. 𝐔𝐬𝐞𝐫 𝐈𝐧𝐟𝐨: /𝐢𝐧𝐟𝐨
    5. 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐁𝐚𝐥𝐚𝐧𝐜𝐞: /𝐜𝐫𝐞𝐝𝐢𝐭𝐬

~ 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 & 𝐏𝐫𝐞𝐦𝐢𝐮𝐦𝐬:
    6. 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐒𝐲𝐬𝐭𝐞𝐦: /𝐡𝐨𝐰𝐜𝐫𝐝
    7. 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐏𝐫𝐢𝐯𝐢𝐥𝐞𝐠𝐞𝐬: /𝐡𝐨𝐰𝐩𝐦
    8. 𝐁𝐮𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦: /𝐛𝐮𝐲

~ 𝐂𝐨𝐦𝐦𝐮𝐧𝐢𝐭𝐲 𝐓𝐨𝐨𝐥𝐬:
    9. 𝐀𝐝𝐝 𝐭𝐨 𝐆𝐫𝐨𝐮𝐩: /𝐡𝐨𝐰𝐠𝐩

~ 𝐓𝐞𝐜𝐡 𝐒𝐮𝐩𝐩𝐨𝐫𝐭:
    10. 𝐏𝐢𝐧𝐠 𝐒𝐭𝐚𝐭𝐮𝐬: /𝐩𝐢𝐧𝐠

𝐓𝐨𝐭𝐚𝐥 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬: 10

        """

        CHARGE_BUTTON = [
            [
                InlineKeyboardButton("𝐁𝐚𝐜𝐤", callback_data="HELPER"),
                InlineKeyboardButton("𝐂𝐥𝐨𝐬𝐞", callback_data="close")
            ]
        ]
        await CallbackQuery.edit_message_text(
            text=CHARGE_TEXT,
            reply_markup=InlineKeyboardMarkup(CHARGE_BUTTON)
        )
