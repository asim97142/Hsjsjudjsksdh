from pyrogram import Client, filters
from FUNC.usersdb_func import *


async def get_user_info(user_id, client, message):
    try:
        user_id     = str(message.text.split(" ")[1])
        get         = await client.get_users(user_id)
        name        = get.first_name
        id          = get.id
        username    = get.username
        restriction = get.restriction_reason
        scam        = get.scam
        premium     = get.is_premium

        resp = f"""<b>
ヸ 𝐈𝐧𝐟𝐨 𝐨𝐟 '{user_id}' 𝐨𝐧 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦
━━━━━━━━━━━━━━
👤 𝐅𝐢𝐫𝐬𝐭 𝐍𝐚𝐦𝐞: {name}
🆔 𝐈𝐃: {id}
📛 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞: @{username}
🔗 𝐏𝐫𝐨𝐟𝐢𝐥𝐞 𝐋𝐢𝐧𝐤: <a href="tg://user?id={id}">Profile Link</a>
🔒 𝐓𝐆 𝐑𝐞𝐬𝐭𝐫𝐢𝐜𝐭𝐢𝐨𝐧𝐬: {restriction}
🚨 𝐓𝐆 𝐒𝐜𝐚𝐦𝐭𝐚𝐠: {scam}
🌟 𝐓𝐆 𝐏𝐫𝐞𝐦𝐢𝐮𝐦: {premium}
    </b> """
        await message.reply_text(resp, quote=True)

    except Exception:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_message(filters.command("id", [".", "/"]))
async def cmd_id(client, message):
    try:
        if len(message.text.split(" ")) > 1:
            await get_user_info(message.text.split(" ")[1], client, message)
        else:
            if message.reply_to_message:
                user_info = message.reply_to_message.from_user
            else:
                user_info = message.from_user

            texta = f"""<b>
Hey <a href="tg://user?id={user_info.id}"> {user_info.first_name}</a>!
𝐘𝐨𝐮𝐫 𝐔𝐬𝐞𝐫 𝐈𝐃: <code>{user_info.id}</code>
𝐓𝐡𝐢𝐬 𝐂𝐡𝐚𝐭 𝐈𝐃: <code>{message.chat.id}</code>
    </b>"""
            await message.reply_text(texta, quote=True)
    except Exception:
        import traceback
        await error_log(traceback.format_exc())
