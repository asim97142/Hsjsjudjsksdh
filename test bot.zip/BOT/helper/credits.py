from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("credits", [".", "/"]))
async def cmd_credit(Client, message):
    try:
        user_id = str(message.from_user.id)
        regdata = await getuserinfo(user_id)
        regdata = str(regdata)
        if regdata == "None":
            resp = f"""<b>
𝐔𝐧𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐔𝐬𝐞𝐫𝐬 ⚠️  

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐂𝐚𝐧'𝐭 𝐔𝐬𝐞 𝐌𝐞 𝐔𝐧𝐥𝐞𝐬𝐬 𝐘𝐨𝐮 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐅𝐢𝐫𝐬𝐭.

𝐓𝐲𝐩𝐞 /𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp, message.id)
            return

        getuser    = await getuserinfo(user_id)
        status     = getuser["status"]
        credit     = getuser["credit"]
        plan       = getuser["plan"]
        first_name = str(message.from_user.first_name)

        resp = f"""<b>
𝐍𝐚𝐦𝐞: {first_name}
𝐂𝐫𝐞𝐝𝐢𝐭𝐬: {credit}
𝐒𝐭𝐚𝐭𝐮𝐬: {status}
𝐏𝐥𝐚𝐧: {plan}

𝐖𝐚𝐧𝐭 𝐌𝐨𝐫𝐞 ? 𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐭𝐨 𝐆𝐞𝐭 𝐦𝐨𝐫𝐞.
    </b>"""
        await message.reply_text(resp, message.id)
    except:
        import traceback
        await error_log(traceback.format_exc())
