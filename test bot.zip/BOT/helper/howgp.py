from pyrogram import Client, filters
from FUNC.defs import *


@Client.on_message(filters.command("howgp", [".", "/"]))
async def cmd_howgp(Client, message):
    try:
        texta = f"""<b>
𝐓𝐎 𝐓𝐇𝐈𝐒 𝐀𝐃𝐃 𝐓𝐇𝐈𝐒 𝐁𝐎𝐓 𝐓𝐎 𝐘𝐎𝐔𝐑 𝐆𝐑𝐎𝐔𝐏 -

Requirements: <b>𝐘𝐨𝐮𝐫 𝐆𝐫𝐨𝐮𝐩 𝐌𝐮𝐬𝐭 𝐇𝐚𝐯𝐞 𝐀𝐭𝐥𝐞𝐚𝐬𝐭 50 𝐌𝐞𝐦𝐛𝐞𝐫𝐬.</b>

𝐒𝐭𝐞𝐩𝐬 𝐓𝐨 𝐆𝐞𝐭 𝐘𝐨𝐮𝐫 𝐆𝐫𝐨𝐮𝐩 𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐬𝐞𝐝:
➔ 𝐀𝐝𝐝 @𝐒𝐏𝐘𝐱𝐂𝐇𝐊_𝐁𝐎𝐓 𝐓𝐨 𝐘𝐨𝐮𝐫 𝐆𝐫𝐨𝐮𝐩 𝐀𝐬 𝐀𝐝𝐦𝐢𝐧 .
➔ 𝐂𝐨𝐩𝐲 𝐘𝐨𝐮𝐫 𝐆𝐫𝐨𝐮𝐩 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐨𝐫 𝐆𝐫𝐨𝐮𝐩 𝐈𝐧𝐯𝐢𝐭𝐞 𝐋𝐢𝐧𝐤 .
➔ 𝐊𝐧𝐨𝐜𝐤 @𝐒𝐏𝐘𝐱𝐒𝐏𝐈𝐃𝐄𝐘 𝐀𝐧𝐝 𝐆𝐢𝐯𝐞 𝐇𝐢𝐦 𝐓𝐡𝐞 𝐆𝐫𝐨𝐮𝐩 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐨𝐫 𝐆𝐫𝐨𝐮𝐩 𝐈𝐧𝐯𝐢𝐭𝐞 𝐋𝐢𝐧𝐤

𝐓𝐡𝐚𝐭𝐬 𝐈𝐭. 𝐍𝐨𝐰 𝐖𝐚𝐢𝐭 𝐓𝐢𝐥𝐥 𝐀𝐩𝐩𝐫𝐨𝐯𝐚𝐥 𝐅𝐨𝐫 𝐘𝐨𝐮𝐫 𝐆𝐫𝐨𝐮𝐩 ✅ .
</b>"""
        await message.reply_text(texta, message.id)

    except Exception as e:
        import traceback

        await error_log(traceback.format_exc())
