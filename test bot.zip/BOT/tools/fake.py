from pyrogram import Client, filters
from faker import Faker
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *

@Client.on_message(filters.command("fake", [".", "/"]))
async def cmd_fake(Client, message):
    try:
        # Check initial conditions
        checkall = await check_all_thing(Client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        try:
            # Get country code from the message or default to 'us'
            country_code = message.text.split(" ")[1].lower() if len(message.text.split(" ")) > 1 else 'us'

            # Supported countries in Faker
            supported_locales = {
                'us': ('en_US', 'United States 🇺🇸'),
                'gb': ('en_GB', 'United Kingdom 🇬🇧'),
                'fr': ('fr_FR', 'France 🇫🇷'),
                'de': ('de_DE', 'Germany 🇩🇪'),
                'es': ('es_ES', 'Spain 🇪🇸'),
                'it': ('it_IT', 'Italy 🇮🇹'),
                'jp': ('ja_JP', 'Japan 🇯🇵'),
                'in': ('en_IN', 'India 🇮🇳'),
                'au': ('en_AU', 'Australia 🇦🇺'),
                'ca': ('en_CA', 'Canada 🇨🇦'),
                'mx': ('es_MX', 'Mexico 🇲🇽'),
                'br': ('pt_BR', 'Brazil 🇧🇷'),
                'ru': ('ru_RU', 'Russia 🇷🇺'),
                'cn': ('zh_CN', 'China 🇨🇳'),
                'za': ('en_ZA', 'South Africa 🇿🇦'),
                'nl': ('nl_NL', 'Netherlands 🇳🇱'),
                'pl': ('pl_PL', 'Poland 🇵🇱'),
                'se': ('sv_SE', 'Sweden 🇸🇪'),
                'no': ('no_NO', 'Norway 🇳🇴'),
                'fi': ('fi_FI', 'Finland 🇫🇮'),
                'dk': ('da_DK', 'Denmark 🇩🇰'),
                'kr': ('ko_KR', 'South Korea 🇰🇷'),
                'tr': ('tr_TR', 'Turkey 🇹🇷'),
                'id': ('id_ID', 'Indonesia 🇮🇩'),
                'th': ('th_TH', 'Thailand 🇹🇭'),
                'vn': ('vi_VN', 'Vietnam 🇻🇳'),
                'gr': ('el_GR', 'Greece 🇬🇷'),
                'cz': ('cs_CZ', 'Czech Republic 🇨🇿'),
                'hu': ('hu_HU', 'Hungary 🇭🇺'),
                'ro': ('ro_RO', 'Romania 🇷🇴'),
                'ar': ('ar_SA', 'Saudi Arabia 🇸🇦'),
                'il': ('he_IL', 'Israel 🇮🇱'),
                'pt': ('pt_PT', 'Portugal 🇵🇹'),
                'bg': ('bg_BG', 'Bulgaria 🇧🇬'),
                'ua': ('uk_UA', 'Ukraine 🇺🇦'),
                'pk': ('en_PK', 'Pakistan 🇵🇰'),
                'ph': ('tl_PH', 'Philippines 🇵🇭'),
                'eg': ('ar_EG', 'Egypt 🇪🇬'),
                'cl': ('es_CL', 'Chile 🇨🇱'),
                'tw': ('zh_TW', 'Taiwan 🇹🇼'),
                'sa': ('ar_SA', 'Saudi Arabia 🇸🇦'),
                'np': ('ne_NP', 'Nepal 🇳🇵'),
                'bd': ('bn_BD', 'Bangladesh 🇧🇩'),
                'ae': ('ar_AE', 'United Arab Emirates 🇦🇪'),
                'bh': ('ar_BH', 'Bahrain 🇧🇭'),
                'jo': ('ar_JO', 'Jordan 🇯🇴'),
                'iq': ('ar_IQ', 'Iraq 🇮🇶'),
                'ps': ('ar_PS', 'Palestine 🇵🇸')
            }

            if country_code == "hfake" or country_code == "/hfake":
                # Display all supported countries with flags and command
                countries_list = "\n".join([f"For {value[1]}: Use <code>/{key}</code>" for key, value in supported_locales.items()])
                await message.reply_text(f"Here are the supported countries:\n{countries_list}")
                return

            # Get locale and country name for the provided country code
            locale, country_name = supported_locales.get(country_code, ('en_US', 'United States 🇺🇸'))

            # Initialize Faker with the selected locale
            fake = Faker(locale)

            # Generate fake details with fallback for missing attributes
            fake_name = fake.name()
            fake_address = fake.street_address() if hasattr(fake, "street_address") else "N/A"
            fake_city = fake.city() if hasattr(fake, "city") else "N/A"
            fake_state = fake.state() if hasattr(fake, "state") else "N/A"
            fake_zipcode = fake.postcode() if hasattr(fake, "postcode") else "N/A"
            fake_gender = fake.random_element(elements=("Male", "Female"))
            fake_phone = fake.phone_number() if hasattr(fake, "phone_number") else "N/A"

            # Enforce the correct country name
            fake_country = country_name

            # Construct the response message
            resp = f"""
<b>Fake Info Created Successfully ✅</b>
━━━━━━━━━━━━━━
🆔 <b>𝐅𝐮𝐥𝐥 𝐍𝐚𝐦𝐞:</b> <code>{fake_name}</code>
👤 <b>𝐆𝐞𝐧𝐝𝐞𝐫:</b> <code>{fake_gender}</code>
🏠 <b>𝐒𝐭𝐫𝐞𝐞𝐭:</b> <code>{fake_address}</code>
🏙️ <b>𝐂𝐢𝐭𝐲/𝐓𝐨𝐰𝐧/𝐕𝐢𝐥𝐥𝐚𝐠𝐞:</b> <code>{fake_city}</code>
🌍 <b>𝐒𝐭𝐚𝐭𝐞/𝐏𝐫𝐨𝐯𝐢𝐧𝐜𝐞/𝐑𝐞𝐠𝐢𝐨𝐧:</b> <code>{fake_state}</code>
📮 <b>𝐏𝐨𝐬𝐭𝐚𝐥 𝐂𝐨𝐝𝐞:</b> <code>{fake_zipcode}</code>
📞 <b>𝐏𝐡𝐨𝐧𝐞 𝐍𝐮𝐦𝐛𝐞𝐫:</b> <code>{fake_phone}</code>
🌏 <b>𝐂𝐨𝐮𝐧𝐭𝐫𝐲:</b> <code>{fake_country}</code>
━━━━━━━━━━━━━━
<b>𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> [ {role} ]
<b>𝐁𝐨𝐭 𝐁𝐲:</b> <a href="tg://user?id=7317502701">SPYxSPYDE ⚡</a>
"""
            # Reply to the original message
            await message.reply_text(resp)

        except Exception as e:
            # Log errors with traceback
            import traceback
            await error_log(traceback.format_exc())

    except Exception as outer_exception:
        # Log outer errors with traceback
        import traceback
        await error_log(traceback.format_exc())
from pyrogram import Client, filters

@Client.on_message(filters.command("hfake", [".", "/"]))
async def cmd_hfake(Client, message):
    try:
        # Check initial conditions
        checkall = await check_all_thing(Client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        # Define a dictionary for supported countries and their flags
        supported_locales = {
            'us': ('United States 🇺🇸', '/fake us'),
            'gb': ('United Kingdom 🇬🇧', '/fake gb'),
            'fr': ('France 🇫🇷', '/fake fr'),
            'de': ('Germany 🇩🇪', '/fake de'),
            'es': ('Spain 🇪🇸', '/fake es'),
            'it': ('Italy 🇮🇹', '/fake it'),
            'jp': ('Japan 🇯🇵', '/fake jp'),
            'in': ('India 🇮🇳', '/fake in'),
            'au': ('Australia 🇦🇺', '/fake au'),
            'ca': ('Canada 🇨🇦', '/fake ca'),
            'mx': ('Mexico 🇲🇽', '/fake mx'),
            'br': ('Brazil 🇧🇷', '/fake br'),
            'ru': ('Russia 🇷🇺', '/fake ru'),
            'cn': ('China 🇨🇳', '/fake cn'),
            'nl': ('Netherlands 🇳🇱', '/fake nl'),
            'pl': ('Poland 🇵🇱', '/fake pl'),
            'se': ('Sweden 🇸🇪', '/fake se'),
            'no': ('Norway 🇳🇴', '/fake no'),
            'fi': ('Finland 🇫🇮', '/fake fi'),
            'dk': ('Denmark 🇩🇰', '/fake dk'),
            'kr': ('South Korea 🇰🇷', '/fake kr'),
            'tr': ('Turkey 🇹🇷', '/fake tr'),
            'id': ('Indonesia 🇮🇩', '/fake id'),
            'th': ('Thailand 🇹🇭', '/fake th'),
            'vn': ('Vietnam 🇻🇳', '/fake vn'),
            'gr': ('Greece 🇬🇷', '/fake gr'),
            'cz': ('Czech Republic 🇨🇿', '/fake cz'),
            'hu': ('Hungary 🇭🇺', '/fake hu'),
            'ro': ('Romania 🇷🇴', '/fake ro'),
            'ar': ('Saudi Arabia 🇸🇦', '/fake ar'),
            'il': ('Israel 🇮🇱', '/fake il'),
            'pt': ('Portugal 🇵🇹', '/fake pt'),
            'bg': ('Bulgaria 🇧🇬', '/fake bg'),
            'ua': ('Ukraine 🇺🇦', '/fake ua'),
            'pk': ('Pakistan 🇵🇰', '/fake pk'),
            'ph': ('Philippines 🇵🇭', '/fake ph'),
            'eg': ('Egypt 🇪🇬', '/fake eg'),
            'tw': ('Taiwan 🇹🇼', '/fake tw'),
            'sa': ('Saudi Arabia 🇸🇦', '/fake sa'),
            'np': ('Nepal 🇳🇵', '/fake np'),
            'bd': ('Bangladesh 🇧🇩', '/fake bd'),
            'ae': ('United Arab Emirates 🇦🇪', '/fake ae'),
            'bh': ('Bahrain 🇧🇭', '/fake bh'),
            'jo': ('Jordan 🇯🇴', '/fake jo'),
            'ps': ('Palestine 🇵🇸', '/fake ps')
        }

        # Generate the formatted list of countries with flags and commands
        countries_list = "\n".join([f"𝐅𝐨𝐫 {value[0]}:\n                 ⤿𝐔𝐬𝐞 <code>{value[1]}</code>" for key, value in supported_locales.items()])

        # Send the response with all countries and their corresponding fake command
        await message.reply_text(f"<b>𝐇𝐞𝐫𝐞 𝐚𝐫𝐞 𝐭𝐡𝐞 𝐬𝐮𝐩𝐩𝐨𝐫𝐭𝐞𝐝 𝐜𝐨𝐮𝐧𝐭𝐫𝐢𝐞𝐬:</b>\n\n{countries_list}")

    except Exception as e:
        # Log errors if necessary
        import traceback
        await error_log(traceback.format_exc())
