import httpx
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *

IPINFO_API_KEY = "9c3a2f3c00225d"  # Replace with your ipinfo.io API key

@Client.on_message(filters.command("ip", [".", "/"]))
async def cmd_bin(Client, message):
    try:
        checkall = await check_all_thing(Client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        try:
            if message.reply_to_message:
                ip_address = str(message.reply_to_message.text)
            else:
                ip_address = str(message.text.split(" ")[1])
        except:
            resp = """<b>
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐈𝐏 𝐀𝐝𝐝𝐫𝐞𝐬𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 𝐕𝐚𝐥𝐢𝐝 𝐈𝐏 𝐀𝐝𝐝𝐫𝐞𝐬𝐬 𝐅𝐫𝐨𝐦 𝐘𝐨𝐮𝐫 𝐈𝐧𝐩𝐮𝐭.
            </b>"""
            await message.reply_text(resp)
            return

        try:
            async with httpx.AsyncClient() as session:
                # Fetch IP information using freeipapi.com
                url = f"https://freeipapi.com/api/json/{ip_address}"
                response = await session.get(url)
                data = response.json()

                # Fetch scam score using ipinfo.io
                ipinfo_response = await session.get(f"https://ipinfo.io/{ip_address}/json?token={IPINFO_API_KEY}")
                ipinfo_data = ipinfo_response.json()

        except httpx.HTTPError as http_err:
            await error_log(f"HTTP Error: {http_err}")
            resp = """<b>
𝐄𝐫𝐫𝐨𝐫 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐈𝐏 𝐢𝐧𝐟𝐨 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐟𝐞𝐭𝐜𝐡 𝐈𝐏 𝐢𝐧𝐟𝐨. 𝐂𝐡𝐞𝐜𝐤 𝐢𝐟 𝐭𝐡𝐞 𝐈𝐏 𝐢𝐬 𝐯𝐚𝐥𝐢𝐝.
            </b>"""
            await message.reply_text(resp)
            return
        except Exception as e:
            await error_log(f"Error: {e}")
            resp = """<b>
𝐄𝐫𝐫𝐨𝐫 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐈𝐏 𝐢𝐧𝐟𝐨 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐟𝐞𝐭𝐜𝐡 𝐈𝐏 𝐢𝐧𝐟𝐨. 𝐂𝐡𝐞𝐜𝐤 𝐢𝐟 𝐭𝐡𝐞 𝐈𝐏 𝐢𝐬 𝐯𝐚𝐥𝐢𝐝.
            </b>"""
            await message.reply_text(resp)
            return

        IpVersion = data.get('ipVersion')
        IpAddress = data.get('ipAddress')
        Country = data.get('countryName')
        timezone = ipinfo_data.get('timezone')
        CountryCode = data.get('countryCode')
        ZipCode = data.get('zipCode')
        CityName = data.get('cityName')
        RegionName = data.get('regionName')
        ProxyCheck = data.get('isProxy')
        Continent = data.get('continent')

        resp = f"""<b>𝐈𝐏 𝐀𝐝𝐝𝐫𝐞𝐬𝐬 𝐅𝐞𝐭𝐜𝐡𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅</b>
━━━━━━━━━━━━━━
🌐 <b>IP:</b> <code>{IpAddress}</code>
🆔 <b>IP Version:</b> <code>{IpVersion}</code>
🌍 <b>Country:</b> <code>{Country}</code> -> <code>{CountryCode}</code>
🕰️ <b>Time Zone:</b> <code>{timezone}</code>
📮 <b>Zip Code:</b> <code>{ZipCode}</code>
🏙️ <b>City Name:</b> <code>{CityName}</code>
🌍 <b>Region Name:</b> <code>{RegionName}</code>
🛡️ <b>Proxy Check:</b> <code>{ProxyCheck}</code>
🌏 <b>Continent:</b> <code>{Continent}</code>
━━━━━━━━━━━━━━
<b>𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> [ {role} ]
<b>𝐁𝐨𝐭 𝐛𝐲 ➺</b> <a href="tg://user?id=6382444980">〄 ROLEX</a>
"""
        await message.reply_text(resp)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
