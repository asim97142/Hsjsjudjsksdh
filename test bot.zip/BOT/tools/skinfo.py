import httpx
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *

@Client.on_message(filters.command("skinfo", [".", "/"]))
async def cmd_bin(Client, message):
    try:
        checkall = await check_all_thing(Client, message)
        if not checkall[0]:
            return

        role = checkall[1]
        try:
            sk = message.text.split(" ")[1]
        except IndexError:
            resp = """<b>
𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐒𝐊 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 𝐀𝐧𝐲 𝐕𝐚𝐥𝐢𝐝 𝐒𝐊 𝐅𝐫𝐨𝐦 𝐘𝐨𝐮𝐫 𝐈𝐧𝐩𝐮𝐭.
            </b>"""
            await message.reply_text(resp)
            return

        skinfo = None
        session = httpx.AsyncClient()
        try:
            headers = {
                "Authorization": f"Bearer {sk}"
            }
            # Fetch SK info
            skinfo_response = await session.get("https://api.stripe.com/v1/account", headers=headers)
            skinfo = skinfo_response.json()

            # Fetch balance info
            balance_response = await session.get("https://api.stripe.com/v1/balance", headers=headers)
            balance_info = balance_response.json()
        except Exception as e:
            await error_log(str(e))
            resp = """<b>
𝐄𝐫𝐫𝐨𝐫 𝐟𝐞𝐭𝐜𝐡𝐢𝐧𝐠 𝐒𝐊 𝐢𝐧𝐟𝐨 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐟𝐞𝐭𝐜𝐡 𝐒𝐊 𝐢𝐧𝐟𝐨. 𝐂𝐡𝐞𝐜𝐤 𝐢𝐟 𝐭𝐡𝐞 𝐒𝐊 𝐢𝐬 𝐯𝐚𝐥𝐢𝐝.
            </b>"""
            await message.reply_text(resp)
            return
        finally:
            await session.aclose()

        charges_enabled = skinfo.get("charges_enabled", False)

        if charges_enabled:
            # If charges are enabled, call the addsk function
            await addsk(sk)

        url = skinfo.get("business_profile", {}).get("url", "N/A")
        name_data = skinfo.get("business_profile", {}).get("name", "N/A")
        currency = skinfo.get("default_currency", "N/A").upper()
        country = skinfo.get("country", "N/A")
        email = skinfo.get("email", "N/A")
        available_balance = balance_info.get("available", [{}])[0].get("amount", "N/A")
        pending_balance = balance_info.get("pending", [{}])[0].get("amount", "N/A")
        livemode = balance_info.get("livemode", False)

        resp = f"""<b>𝐒𝐊 𝐈𝐧𝐟𝐨 𝐅𝐞𝐭𝐜𝐡𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ✅</b>
━━━━━━━━━━━━━━
🔑 <b>𝐒𝐊:</b> <code>{sk}</code>
🏢 <b>𝐍𝐚𝐦𝐞:</b> {name_data}
🌐 <b>𝐒𝐢𝐭𝐞 𝐈𝐧𝐟𝐨:</b> {url}
🌍 <b>𝐂𝐨𝐮𝐧𝐭𝐫𝐲:</b> {country}
💱 <b>𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲:</b> {currency}
📧 <b>𝐄𝐦𝐚𝐢𝐥:</b> {email}
💰 <b>𝐁𝐚𝐥𝐚𝐧𝐜𝐞 𝐈𝐧𝐟𝐨:</b>
  - 𝐋𝐢𝐯𝐞 𝐌𝐨𝐝𝐞: {livemode}
  - 𝐂𝐡𝐚𝐫𝐠𝐞𝐬 𝐄𝐧𝐚𝐛𝐥𝐞𝐝: {charges_enabled}
  - 𝐀𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 𝐁𝐚𝐥𝐚𝐧𝐜𝐞: {available_balance}
  - 𝐏𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐚𝐥𝐚𝐧𝐜𝐞: {pending_balance}
━━━━━━━━━━━━━━
<b>𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐁𝐲:</b> <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> [ {role} ]
<b>𝐁𝐨𝐭 𝐛𝐲:</b> <a href="tg://user?id=6382444980">〄 ROLEX</a>
"""
        await message.reply_text(resp)

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
