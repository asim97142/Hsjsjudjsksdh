from pyrogram import Client, filters
from FUNC.usersdb_func import *


@Client.on_message(filters.command("gethits", [".", "/"]))
async def cmd_buy(Client, message):
    try:
        try:
            user_id = str(message.from_user.id)
            key = message.text.split(" ")[1]
            file = f"HITS/{key}.txt"
            text = f"""<b>🅷🅸🆃🆂 🅵🅸🅻🅴 🆂🆄🅲🅲🅴🆂🆂🅵🆄🅻🅻🆈 🆁🅴🆃🆁🅸🅴🆅🅴🅳 ✅</b>
━━━━━━━━━━━━━━
🆔 <b>𝐘𝐨𝐮𝐫 𝐔𝐬𝐞𝐫 𝐈𝐃:</b> <code>{user_id}</code>
🔑 <b>𝐇𝐢𝐭𝐬 𝐊𝐞𝐲:</b> <code>{key}</code>
📄 <b>𝐒𝐭𝐚𝐭𝐮𝐬:</b> <code>Successful</code>
━━━━━━━━━━━━━━
"""
            await message.reply_document(
                document=file,
                caption=text,
                reply_to_message_id=message.id
            )
        except Exception:
            await message.reply_text(f"""<b>
FILE FETCH FAILED❌
━━━━━━━━━━━━━━
𝐑𝐞𝐚𝐬𝐨𝐧: 𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐨𝐫 𝐈𝐧𝐜𝐨𝐫𝐫𝐞𝐜𝐭 𝐒𝐞𝐜𝐫𝐞𝐭 𝐊𝐞𝐲
━━━━━━━━━━━━━━</b>""",
                                    reply_to_message_id=message.id)
    except Exception:
        import traceback
        await error_log(traceback.format_exc())
