import json
from pyrogram import Client, filters
from FUNC.defs import *
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *
from FUNC.scraperfunc import *


with open("FILES/config.json", "r",encoding="utf-8") as f:
    DATA     = json.load(f)
    API_ID   = DATA["API_ID"]
    API_HASH = DATA["API_HASH"]

user = Client("Scrapper",
              api_id   = API_ID,
              api_hash = API_HASH )



@Client.on_message(filters.command("scr", [".", "/"]))
async def scrapper_cc(Client, message):
    try:
        checkall = await check_all_thing(Client , message)
        if checkall[0] == False:
            return

        role = checkall[1]
        try:
            channel_link = message.text.split(" ")[1]
            limit        = int(message.text.split(" ")[2])
        except:
            resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐅𝐨𝐫𝐦𝐚𝐭 ❌

𝐔𝐬𝐚𝐠𝐞:
𝐅𝐨𝐫 𝐏𝐮𝐛𝐥𝐢𝐜 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫 𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 50</code>

𝐅𝐨𝐫 𝐏𝐫𝐢𝐯𝐚𝐭𝐞 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/+𝐚𝐆𝐖𝐑𝐆𝐳 50</code>
        </b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "FREE" and int(limit) > 2000:
            resp = """<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 2000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞 . 𝐁𝐮𝐲 𝐏𝐥𝐚𝐧 𝐭𝐨 𝐈𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐘𝐨𝐮𝐫 𝐋𝐢𝐦𝐢𝐭 .

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐅𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "PREMIUM" and int(limit) > 10000:
            resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 10000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞.
</b>"""
            await message.reply_text(resp, message.id)
            return
        try:
            await user.start()
        except:
            pass

        if "https" in channel_link:
            check_link = await check_invite_link(user, channel_link)
            if check_link == False:
                resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐈𝐧𝐯𝐢𝐭𝐞 𝐋𝐢𝐧𝐤 ❌

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐋𝐢𝐧𝐤 𝐢𝐬 𝐖𝐫𝐨𝐧𝐠. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐂𝐡𝐞𝐜𝐤 𝐘𝐨𝐮𝐫 𝐋𝐢𝐧𝐤 𝐚𝐧𝐝 𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧.

</b>"""
                await message.reply_text(resp, message.id)
                return

            channel_id    = check_link[1]
            channel_title = check_link[2]
            await cc_private_scrape(message, user, Client, channel_id, channel_title, limit, role)

        else:
            resp = f"""<b>
𝐆𝐚𝐭𝐞: 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 ♻️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠{limit} 𝐂𝐂 𝐅𝐫𝐨𝐦 @{channel_link}. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭.

𝐒𝐭𝐚𝐭𝐮𝐬: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠...
        </b> """
            delete = await message.reply_text(resp, message.id)
            await cc_public_scrape(message, user, Client, channel_link, limit, delete, role)

    except:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_message(filters.command("scrsk", [".", "/"]))
async def scrapper_sk(Client, message):
    try:
        checkall = await check_all_thing(Client , message)
        if checkall[0] == False:
            return

        role = checkall[1]
        try:
            channel_link = message.text.split(" ")[1]
            limit        = int(message.text.split(" ")[2])
        except:
            resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐅𝐨𝐫𝐦𝐚𝐭 ❌

𝐔𝐬𝐚𝐠𝐞:
𝐅𝐨𝐫 𝐏𝐮𝐛𝐥𝐢𝐜 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫𝐬𝐤 𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 50</code>

𝐅𝐨𝐫 𝐏𝐫𝐢𝐯𝐚𝐭𝐞 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫𝐬𝐤 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/+𝐚𝐆𝐖𝐑𝐆𝐳 50</code>
        </b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "FREE" and int(limit) > 2000:
            resp = """<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 2000 𝐒𝐊 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞. 𝐁𝐮𝐲 𝐏𝐥𝐚𝐧 𝐭𝐨 𝐈𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐘𝐨𝐮𝐫 𝐋𝐢𝐦𝐢𝐭.

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐅𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "PREMIUM" and int(limit) > 10000:
            resp = """<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 10000 𝐒𝐊 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞.

</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            await user.start()
        except:
            pass

        if "https" in channel_link:
            check_link = await check_invite_link(user, channel_link)
            if check_link == False:
                resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐈𝐧𝐯𝐢𝐭𝐞 𝐋𝐢𝐧𝐤 ❌

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐋𝐢𝐧𝐤 𝐢𝐬 𝐖𝐫𝐨𝐧𝐠. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐂𝐡𝐞𝐜𝐤 𝐘𝐨𝐮𝐫 𝐋𝐢𝐧𝐤 𝐚𝐧𝐝 𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧.

</b>"""
                await message.reply_text(resp, message.id)
                return

            channel_id    = check_link[1]
            channel_title = check_link[2]
            await sk_private_scrape(message, user, Client, channel_id, channel_title, limit, role)
        else:
            resp = f"""<b>
𝐆𝐚𝐭𝐞: 𝐒𝐊 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 ♻️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠 {limit} 𝐒𝐊 𝐅𝐫𝐨𝐦 @{channel_link}. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭.

𝐒𝐭𝐚𝐭𝐮𝐬: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠...
        </b> """
            delete = await message.reply_text(resp, message.id)
            await sk_public_scrape(message, user, Client, channel_link, limit, delete, role)

    except:
        import traceback
        await error_log(traceback.format_exc())


@Client.on_message(filters.command("scrbin", [".", "/"]))
async def scrapper_bin(Client, message):
    try:
        checkall = await check_all_thing(Client , message)
        if checkall[0] == False:
            return

        role = checkall[1]
        try:
            scrape_bin   = message.text.split(" ")[1]
            channel_link = message.text.split(" ")[2]
            limit        = int(message.text.split(" ")[3])
        except:
            resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐅𝐨𝐫𝐦𝐚𝐭 ❌ 

𝐔𝐬𝐚𝐠𝐞:
𝐅𝐨𝐫 𝐏𝐮𝐛𝐥𝐢𝐜 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫𝐛𝐢𝐧 𝐛𝐢𝐧 𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 50</code>

𝐅𝐨𝐫 𝐏𝐫𝐢𝐯𝐚𝐭𝐞 𝐆𝐫𝐨𝐮𝐩 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠
<code>/𝐬𝐜𝐫𝐛𝐢𝐧 𝐛𝐢𝐧 𝐡𝐭𝐭𝐩𝐬://𝐭.𝐦𝐞/+𝐚𝐆𝐖𝐑𝐆𝐳 50</code>
        </b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "FREE" and int(limit) > 2000:
            resp = """<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 2000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞. 𝐁𝐮𝐲 𝐏𝐥𝐚𝐧 𝐭𝐨 𝐈𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐘𝐨𝐮𝐫 𝐋𝐢𝐦𝐢𝐭.

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐅𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            await message.reply_text(resp, message.id)
            return

        if role == "PREMIUM" and int(limit) > 10000:
            resp = """<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐂𝐚𝐧 𝐒𝐜𝐫𝐚𝐩𝐞 10000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞.

</b>"""
            await message.reply_text(resp, message.id)
            return

        try:
            await user.start()
        except:
            pass

        if "https" in channel_link:
            check_link = await check_invite_link(user, channel_link)
            if check_link == False:
                resp = f"""<b>
𝐖𝐫𝐨𝐧𝐠 𝐈𝐧𝐯𝐢𝐭𝐞 𝐋𝐢𝐧𝐤 ❌

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐯𝐢𝐝𝐞𝐝 𝐋𝐢𝐧𝐤 𝐢𝐬 𝐖𝐫𝐨𝐧𝐠. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐂𝐡𝐞𝐜𝐤 𝐘𝐨𝐮𝐫 𝐋𝐢𝐧𝐤 𝐚𝐧𝐝 𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧.

</b>"""
                await message.reply_text(resp, message.id)
                return

            channel_id    = check_link[1]
            channel_title = check_link[2]
            await bin_private_scrape(
                message,
                user,
                Client,
                scrape_bin,
                channel_id,
                channel_title,
                limit,
                role,
            )
        else:
            resp = f"""<b>
𝐆𝐚𝐭𝐞: 𝐂𝐂 𝐒𝐜𝐫𝐚𝐩𝐞𝐫 ♻️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠 {limit} 𝐂𝐂 𝐅𝐫𝐨𝐦 @{channel_link}. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐖𝐚𝐢𝐭. 

𝐒𝐭𝐚𝐭𝐮𝐬: 𝐒𝐜𝐫𝐚𝐩𝐢𝐧𝐠...
        </b> """
            delete = await message.reply_text(resp, message.id)
            await bin_public_scrape(
                message,
                user,
                Client,
                scrape_bin,
                channel_link,
                limit,
                delete,
                role,
            )

    except:
        import traceback
        await error_log(traceback.format_exc())
