import json
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from FUNC.defs import *


@Client.on_message(filters.command("delsk", [".", "/"]))
async def delbrod(Client, message):
    try:
        user_id = str(message.from_user.id)
        OWNER_ID = json.loads(
            open("FILES/config.json", "r", encoding="utf-8").read())["OWNER_ID"]
        if user_id not in OWNER_ID:
            resp = """<b>╰┈➤𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 ❤️!</b>"""
            await message.reply_text(resp, message.id)
            return

        if len(message.command) != 2:
            resp = "<b>🅿🅻🅴🅰🆂🅴 🅿🆁🅾🆅🅸🅳🅴 🆃🅷🅴 🆂🅺 🅺🅴🆈 🆃🅾 🅳🅴🅻🅴🆃🅴.</b>"
            await message.reply_text(resp, message.id)
            return

        sk_to_delete = message.command[1]
        await delsk(sk_to_delete)

        resp = "<b>🆂🅺 🅺🅴🆈 (🆂🆃🆁🅸🅿🅴 🅺🅴🆈) 🆂🆄🅲🅲🅴🆂🆂🅵🆄🅻🅻🆈 🅳🅴🅻🅴🆃🅴🅳 ✅</b>"
        await message.reply_text(resp, message.id)

    except:
        import traceback
        await error_log(traceback.format_exc())