import  os
from FUNC.defs import *


async def getcc_for_txt(file_name, role):
    try:
        file = open(f"downloads/{file_name}").read().splitlines()
        os.remove(f"downloads/{file_name}")
        ccs = []
        for i in file:
            get = await getcards(i)
            if get != None:
                cc     = get[0]
                mes    = get[1]
                ano    = get[2]
                cvv    = get[3]
                fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                ccs.append(fullcc)

        if role == "FREE" and len(ccs) > 1000:
            resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐘𝐨𝐮 𝐂𝐚𝐧 𝐂𝐡𝐞𝐜𝐤 1000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞. 𝐁𝐮𝐲 𝐏𝐥𝐚𝐧 𝐭𝐨 𝐈𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐘𝐨𝐮𝐫 𝐋𝐢𝐦𝐢𝐭 .

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐅𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            return False, resp
        if (role == "PREMIUM" or role == "LIFETIME") and len(ccs) > 10000:            
            resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐂𝐚𝐧 𝐂𝐡𝐞𝐜𝐤 10000 𝐂𝐂 𝐚𝐭 𝐚 𝐓𝐢𝐦𝐞. 𝐁𝐮𝐲 𝐏𝐥𝐚𝐧 𝐭𝐨 𝐈𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐘𝐨𝐮𝐫 𝐋𝐢𝐦𝐢𝐭.

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐅𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            return False, resp
        if len(ccs) == 0:
            resp = f"""<b>
𝐂𝐂 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐖𝐞 𝐀𝐫𝐞 𝐔𝐧𝐚𝐛𝐥𝐞 𝐭𝐨 𝐅𝐢𝐧𝐝 𝐀𝐧𝐲 𝐂𝐂 𝐃𝐞𝐭𝐚𝐢𝐥𝐬 𝐅𝐫𝐨𝐦 𝐘𝐨𝐮𝐫 𝐈𝐧𝐩𝐮𝐭. 𝐏𝐫𝐨𝐯𝐢𝐝𝐞 𝐂𝐂'𝐬 𝐃𝐞𝐭𝐚𝐢𝐥𝐬 𝐓𝐨 𝐂𝐡𝐞𝐜𝐤.
</b>"""
            return False, resp
        else:
            return True, ccs

    except:
        return False , "𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧 𝐋𝐚𝐭𝐞𝐫"
