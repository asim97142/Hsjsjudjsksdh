from FUNC.usersdb_func import *
import time
from FUNC.defs import *

gate_active    = json.loads(open("FILES/deadsk.json", "r" , encoding="utf-8").read())["gate_active"]


async def check_all_thing(Client , message):
    try:
        from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

        user_id   = str(message.from_user.id)
        chat_type = str(message.chat.type)
        chat_id   = str(message.chat.id)
        regdata   = await getuserinfo(user_id)
        regdata   = str(regdata)
        if regdata == "None":
            resp = f"""<b>
𝐔𝐧𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐔𝐬𝐞𝐫𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐂𝐚𝐧'𝐭 𝐔𝐬𝐞 𝐌𝐞 𝐔𝐧𝐥𝐞𝐬𝐬 𝐘𝐨𝐮 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐅𝐢𝐫𝐬𝐭 .

𝐓𝐲𝐩𝐞 /𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False , False

        if any(command in message.text for command in gate_active):
            resp = "<b>𝐓𝐡𝐢𝐬 𝐠𝐚𝐭𝐞 𝐧𝐨𝐭 𝐚𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 𝐧𝐨𝐰, 𝐩𝐥𝐞𝐚𝐬𝐞 𝐭𝐫𝐲 𝐚𝐠𝐚𝐢𝐧 𝐥𝐚𝐭𝐞𝐫 👍</b>"
            await message.reply_text(resp, reply_to_message_id=message.id)
            return False, False, False

        getuser        = await getuserinfo(user_id)
        status         = getuser["status"]
        credit         = int(getuser["credit"])
        antispam_time  = int(getuser["antispam_time"])
        now            = int(time.time())
        count_antispam = now - antispam_time
        checkgroup     = await getchatinfo(chat_id)
        checkgroup     = str(checkgroup)
        await plan_expirychk(user_id)

        if chat_type == "ChatType.PRIVATE" and status == "FREE":
            resp = f"""<b>
𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐑𝐞𝐪𝐮𝐢𝐫𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐎𝐧𝐥𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐔𝐬𝐞𝐫𝐬 𝐚𝐫𝐞 𝐀𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐛𝐨𝐭 𝐢𝐧 𝐏𝐞𝐫𝐬𝐨𝐧𝐚𝐥. 𝐉𝐨𝐢𝐧 @SPYxCHK_DISCUSS 𝐚𝐧𝐝 𝐮𝐬𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭 𝐟𝐨𝐫 𝐟𝐫𝐞𝐞.
𝐁𝐮𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐏𝐥𝐚𝐧 𝐔𝐬𝐢𝐧𝐠 /𝐛𝐮𝐲 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        if (
            chat_type == "ChatType.GROUP"
            or chat_type == "ChatType.SUPERGROUP"
            and checkgroup == "None"
        ):
            resp = f"""<b>
𝐔𝐧𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐂𝐡𝐚𝐭𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐎𝐧𝐥𝐲 𝐂𝐡𝐚𝐭𝐬 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 𝐁𝐲 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 𝐂𝐚𝐧 𝐎𝐧𝐥𝐲 𝐔𝐬𝐞 𝐌𝐞. 𝐓𝐨 𝐆𝐞𝐭 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 𝐘𝐨𝐮𝐫 𝐂𝐡𝐚𝐭𝐬 𝐅𝐨𝐥𝐥𝐨𝐰 𝐓𝐡𝐞 𝐒𝐭𝐞𝐩𝐬 .

𝐓𝐲𝐩𝐞 /𝐡𝐨𝐰𝐠𝐩 𝐭𝐨 𝐊𝐧𝐨𝐰 𝐓𝐡𝐞 𝐒𝐭𝐞𝐩
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        if credit < 5:
            resp = f"""<b>
𝐈𝐧𝐬𝐮𝐟𝐟𝐢𝐜𝐢𝐞𝐧𝐭 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐇𝐚𝐯𝐞 𝐈𝐧𝐬𝐮𝐟𝐟𝐢𝐜𝐢𝐞𝐧𝐭 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐭𝐨 𝐔𝐬𝐞 𝐌𝐞. 𝐑𝐞𝐜𝐡𝐚𝐫𝐠𝐞 𝐂𝐫𝐞𝐝𝐢𝐭 𝐅𝐨𝐫 𝐔𝐬𝐢𝐧𝐠 𝐌𝐞

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐭𝐨 𝐑𝐞𝐜𝐡𝐚𝐫𝐠𝐞
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        if status == "PREMIUM" and count_antispam < 5:
            after = 4 - count_antispam
            resp = f"""<b>
𝐀𝐧𝐭𝐢𝐬𝐩𝐚𝐦 𝐃𝐞𝐭𝐞𝐜𝐭𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐀𝐫𝐞 𝐏𝐞𝐫𝐟𝐨𝐫𝐦𝐢𝐧𝐠 𝐚𝐜𝐭𝐢𝐨𝐧𝐬 𝐚𝐭 𝐇𝐢𝐠𝐡 𝐏𝐚𝐜𝐞. 𝐓𝐫𝐲 𝐀𝐟𝐭𝐞𝐫 {after}𝐬 𝐭𝐨 𝐔𝐬𝐞 𝐌𝐞 𝐀𝐠𝐚𝐢𝐧 .

𝐑𝐞𝐝𝐮𝐜𝐞 𝐀𝐧𝐭𝐢𝐬𝐩𝐚𝐦 𝐓𝐢𝐦𝐞 /𝐛𝐮𝐲 𝐔𝐬𝐢𝐧𝐠 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        if status == "FREE" and count_antispam < 20:
            after = 30 - count_antispam
            resp = f"""<b>
𝐀𝐧𝐭𝐢𝐬𝐩𝐚𝐦 𝐃𝐞𝐭𝐞𝐜𝐭𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐀𝐫𝐞 𝐃𝐨𝐢𝐧𝐠 𝐭𝐡𝐢𝐧𝐠𝐬 𝐕𝐞𝐫𝐲 𝐅𝐚𝐬𝐭. 𝐓𝐫𝐲 𝐀𝐟𝐭𝐞𝐫 {after}𝐬 𝐭𝐨 𝐔𝐬𝐞 𝐌𝐞 𝐀𝐠𝐚𝐢𝐧 .

𝐑𝐞𝐝𝐮𝐜𝐞 𝐀𝐧𝐭𝐢𝐬𝐩𝐚𝐦 𝐓𝐢𝐦𝐞 /𝐛𝐮𝐲 𝐔𝐬𝐢𝐧𝐠 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        return True , status
    

    except:
        import traceback
        await error_log(traceback.format_exc())
        try:
            await message.reply_text("𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧 𝐥𝐚𝐭𝐞𝐫" ,  reply_to_message_id = message.id)
        except:
            pass
        return False , False 


async def check_some_thing(Client , message):
    try:
        user_id   = str(message.from_user.id)
        chat_type = str(message.chat.type)
        chat_id   = str(message.chat.id)
        regdata   = await getuserinfo(user_id)
        regdata   = str(regdata)
        if regdata == "None":
            resp = f"""<b>
𝐔𝐧𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫𝐞𝐝 𝐔𝐬𝐞𝐫𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐘𝐨𝐮 𝐂𝐚𝐧'𝐭 𝐔𝐬𝐞 𝐌𝐞 𝐔𝐧𝐥𝐞𝐬𝐬 𝐘𝐨𝐮 𝐑𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐅𝐢𝐫𝐬𝐭 .

𝐓𝐲𝐩𝐞 /𝐫𝐞𝐠𝐢𝐬𝐭𝐞𝐫 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        getuser    = await getuserinfo(user_id)
        status     = getuser["status"]
        checkgroup = await getchatinfo(chat_id)
        checkgroup = str(checkgroup)
        await plan_expirychk(user_id)

        if chat_type == "ChatType.PUBLIC" and status == "FREE":
            resp = """<b>
𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐔𝐬𝐞𝐫𝐬 𝐑𝐞𝐪𝐮𝐢𝐫𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐎𝐧𝐥𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐔𝐬𝐞𝐫𝐬 𝐚𝐫𝐞 𝐀𝐥𝐥𝐨𝐰𝐞𝐝 𝐭𝐨 𝐮𝐬𝐞 𝐛𝐨𝐭 𝐢𝐧 𝐏𝐞𝐫𝐬𝐨𝐧𝐚𝐥. 𝐉𝐨𝐢𝐧 @SPYxCHK_DISCUSS 𝐚𝐧𝐝 𝐮𝐬𝐞 𝐭𝐡𝐞 𝐛𝐨𝐭 𝐟𝐨𝐫 𝐟𝐫𝐞𝐞.
𝐁𝐮𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐏𝐥𝐚𝐧 𝐔𝐬𝐢𝐧𝐠 /𝐛𝐮𝐲 𝐭𝐨 𝐂𝐨𝐧𝐭𝐢𝐧𝐮𝐞
</b>"""
            await message.reply_text(resp , message_id=message.id)
            return False , False

        if (
            chat_type == "ChatType.GROUP"
            or chat_type == "ChatType.SUPERGROUP"
            and checkgroup == "None"
        ):
            resp = f"""<b>
𝐔𝐧𝐚𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 𝐂𝐡𝐚𝐭𝐬 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐎𝐧𝐥𝐲 𝐂𝐡𝐚𝐭𝐬 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 𝐁𝐲 𝐭𝐡𝐞 𝐁𝐨𝐬𝐬 𝐂𝐚𝐧 𝐎𝐧𝐥𝐲 𝐔𝐬𝐞 𝐌𝐞. 𝐓𝐨 𝐆𝐞𝐭 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 𝐘𝐨𝐮𝐫 𝐂𝐡𝐚𝐭𝐬 𝐅𝐨𝐥𝐥𝐨𝐰 𝐓𝐡𝐞 𝐒𝐭𝐞𝐩𝐬 .

𝐓𝐲𝐩𝐞 /𝐡𝐨𝐰𝐠𝐩 𝐭𝐨 𝐊𝐧𝐨𝐰 𝐓𝐡𝐞 𝐒𝐭𝐞𝐩
</b>"""
            await message.reply_text(resp ,  reply_to_message_id = message.id)
            return False , False

        return True , status

    except:
        import traceback
        await error_log(traceback.format_exc())
        try:
            await message.reply_text("𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧 𝐥𝐚𝐭𝐞𝐫" ,  reply_to_message_id = message.id)
        except:
            pass
        return False , False


