from FUNC.defs import * 
import json
import re

async def getcc_for_mass(message, role):
    try:
        ccs = []

        # Extract text from the message or its reply
        if message.reply_to_message:
            text = message.reply_to_message.text
        else:
            text = message.text

        # Extract CC details from the text
        for i in text.split("\n"):
            get = await getcards(i)
            if get is not None:
                cc = get[0]
                mes = get[1]
                ano = get[2]
                cvv = get[3]
                fullcc = f"{cc}|{mes}|{ano}|{cvv}"
                ccs.append(fullcc)

        # Load OWNER_ID from the configuration file
        config = json.loads(open("FILES/config.json", "r", encoding="utf-8").read())
        OWNER_ID = config["OWNER_ID"]

        # Check limits based on role or OWNER_ID
        user_id = str(message.from_user.id)
        if user_id == OWNER_ID:
            # Custom limit for the owner
            if len(ccs) > 1000:
                resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞 : 𝐀𝐬 𝐭𝐡𝐞 𝐛𝐨𝐬𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐨𝐧𝐥𝐲 𝐜𝐡𝐞𝐜𝐤 𝐮𝐩 𝐭𝐨 1000 𝐂𝐂𝐬 𝐚𝐭 𝐚 𝐭𝐢𝐦𝐞. 𝐑𝐞𝐝𝐮𝐜𝐞 𝐭𝐡𝐞 𝐢𝐧𝐩𝐮𝐭 𝐨𝐫 𝐩𝐫𝐨𝐜𝐞𝐬𝐬 𝐢𝐧 𝐛𝐚𝐭𝐜𝐡𝐞𝐬.
</b>"""
                return False, resp
        else:
            # Role-based limits for other users
            if role == "FREE" and len(ccs) > 5:
                resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐜𝐚𝐧 𝐜𝐡𝐞𝐜𝐤 𝐮𝐩 𝐭𝐨 5 𝐂𝐂𝐬 𝐚𝐭 𝐚 𝐭𝐢𝐦𝐞. 𝐓𝐨 𝐢𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐲𝐨𝐮𝐫 𝐥𝐢𝐦𝐢𝐭, 𝐜𝐨𝐧𝐭𝐚𝐜𝐭 @ 𝐟𝐨𝐫 𝐚 𝐜𝐮𝐬𝐭𝐨𝐦 𝐩𝐥𝐚𝐧

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐟𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧𝐬.
</b>"""
                return False, resp
            if (role == "PREMIUM" or role == "LIFETIME") and len(ccs) > 25:            
                resp = f"""<b>
𝐋𝐢𝐦𝐢𝐭 𝐑𝐞𝐚𝐜𝐡𝐞𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐘𝐨𝐮 𝐜𝐚𝐧 𝐜𝐡𝐞𝐜𝐤 𝐮𝐩 𝐭𝐨 25 𝐂𝐂𝐬 𝐚𝐭 𝐚 𝐭𝐢𝐦𝐞. 𝐓𝐨 𝐢𝐧𝐜𝐫𝐞𝐚𝐬𝐞 𝐲𝐨𝐮𝐫 𝐥𝐢𝐦𝐢𝐭, 𝐜𝐨𝐧𝐭𝐚𝐜𝐭 @𝐒𝐏𝐘𝐱𝐒𝐏𝐘𝐃𝐄 𝐟𝐨𝐫 𝐚 𝐜𝐮𝐬𝐭𝐨𝐦 𝐩𝐥𝐚𝐧.

𝐓𝐲𝐩𝐞 /𝐛𝐮𝐲 𝐟𝐨𝐫 𝐏𝐚𝐢𝐝 𝐏𝐥𝐚𝐧𝐬.
</b>"""
                return False, resp

        # Handle case where no valid CCs are found
        if len(ccs) == 0:
            resp = f"""<b>
𝐂𝐂 𝐍𝐨𝐭 𝐅𝐨𝐮𝐧𝐝 ⚠️

𝐌𝐞𝐬𝐬𝐚𝐠𝐞: 𝐍𝐨 𝐂𝐂 𝐝𝐞𝐭𝐚𝐢𝐥𝐬 𝐰𝐞𝐫𝐞 𝐟𝐨𝐮𝐧𝐝 𝐢𝐧 𝐲𝐨𝐮𝐫 𝐢𝐧𝐩𝐮𝐭. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐯𝐚𝐥𝐢𝐝 𝐂𝐂 𝐝𝐞𝐭𝐚𝐢𝐥𝐬 𝐭𝐨 𝐩𝐫𝐨𝐜𝐞𝐞𝐝.
</b>"""
            return False, resp

        # Return valid CC list
        return True, ccs

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
        return False, "𝐓𝐫𝐲 𝐀𝐠𝐚𝐢𝐧 𝐋𝐚𝐭𝐞𝐫"
