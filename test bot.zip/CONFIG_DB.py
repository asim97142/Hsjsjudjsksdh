import pymongo

client = pymongo.MongoClient(
        "mongodb://localhost:27017"
)

result = str(client)

if "connect=True" in result:
    try:
        print("𝐂𝐨𝐧𝐟𝐢𝐠 𝐃𝐁 𝐢𝐬 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 ✅")
    except:
        pass
else:
    try:
        print("𝐂𝐨𝐧𝐟𝐢𝐠 𝐃𝐁 𝐢𝐬 𝐧𝐨𝐭 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 ❌")
    except:
        pass


COLLECTIONS = client["CONFIG_DATABASE"]
BLACKLISTED_SKS = COLLECTIONS.BLACKLISTED_SKS
TOKEN_DB = COLLECTIONS.TOKEN_DB
SKS_DB = COLLECTIONS.SKS_DB