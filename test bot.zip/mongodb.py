import traceback
import pymongo

client = pymongo.MongoClient(
        "mongodb://localhost:27017"

)
result = str(client)

if "connect=True" in result:
    try:
        print("𝐌𝐨𝐧𝐠𝐨𝐃𝐁 𝐢𝐬 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 ✅")
    except:
        pass
else:
    try:
        print("𝐌𝐨𝐧𝐠𝐨𝐃𝐁 𝐢𝐬 𝐧𝐨𝐭 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 ❌")
    except:
        pass

folder = client["MASTER_DATABASE"]
usersdb = folder.USERSDB
chats_auth = folder.CHATS_AUTH
gcdb = folder.GCDB
sksdb = client["SKS_DATABASE"].SKS
confdb = client["SKS_DATABASE"].CONF_DATABASE